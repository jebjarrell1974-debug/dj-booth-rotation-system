import React, { useState, useCallback, useEffect } from 'react';
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { ScrollArea } from "@/components/ui/scroll-area";
import { FolderOpen, Search, Music, RefreshCw, Check, ExternalLink, AlertTriangle } from 'lucide-react';

const SUPPORTED_FORMATS = ['.mp3', '.wav', '.flac', '.m4a', '.ogg', '.aac'];

// Check if we're in an iframe (preview mode)
const isInIframe = () => {
  try {
    return window.self !== window.top;
  } catch (e) {
    return true;
  }
};

export default function MusicLibrary({ 
  onFolderConnected, 
  onTrackSelect,
  selectedTracks = [],
  selectionMode = false,
  musicFolder,
  setMusicFolder 
}) {
  const [tracks, setTracks] = useState([]);
  const [filteredTracks, setFilteredTracks] = useState([]);
  const [searchQuery, setSearchQuery] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const [folderName, setFolderName] = useState('');

  const scanFolder = useCallback(async (dirHandle, path = '') => {
    const files = [];
    
    for await (const entry of dirHandle.values()) {
      if (entry.kind === 'file') {
        const name = entry.name.toLowerCase();
        if (SUPPORTED_FORMATS.some(ext => name.endsWith(ext))) {
          files.push({
            handle: entry,
            name: entry.name,
            path: path ? `${path}/${entry.name}` : entry.name
          });
        }
      } else if (entry.kind === 'directory') {
        const subFiles = await scanFolder(entry, path ? `${path}/${entry.name}` : entry.name);
        files.push(...subFiles);
      }
    }
    
    return files;
  }, []);

  const connectFolder = useCallback(async () => {
    try {
      setIsLoading(true);
      const dirHandle = await window.showDirectoryPicker({
        mode: 'read'
      });
      
      setFolderName(dirHandle.name);
      setMusicFolder(dirHandle);
      
      // Store permission for persistence
      localStorage.setItem('musicFolderName', dirHandle.name);
      
      const files = await scanFolder(dirHandle);
      files.sort((a, b) => a.name.localeCompare(b.name));
      setTracks(files);
      setFilteredTracks(files);
      onFolderConnected?.(dirHandle, files);
    } catch (err) {
      if (err.name !== 'AbortError') {
        console.error('Error accessing folder:', err);
      }
    } finally {
      setIsLoading(false);
    }
  }, [scanFolder, onFolderConnected, setMusicFolder]);

  const reconnectFolder = useCallback(async () => {
    if (musicFolder) {
      setIsLoading(true);
      try {
        // Request permission again
        const permission = await musicFolder.requestPermission({ mode: 'read' });
        if (permission === 'granted') {
          const files = await scanFolder(musicFolder);
          files.sort((a, b) => a.name.localeCompare(b.name));
          setTracks(files);
          setFilteredTracks(files);
          setFolderName(musicFolder.name);
          onFolderConnected?.(musicFolder, files);
        }
      } catch (err) {
        console.error('Error reconnecting:', err);
      } finally {
        setIsLoading(false);
      }
    }
  }, [musicFolder, scanFolder, onFolderConnected]);

  useEffect(() => {
    if (searchQuery.trim() === '') {
      setFilteredTracks(tracks);
    } else {
      const query = searchQuery.toLowerCase();
      setFilteredTracks(tracks.filter(t => 
        t.name.toLowerCase().includes(query) || 
        t.path.toLowerCase().includes(query)
      ));
    }
  }, [searchQuery, tracks]);

  const isSelected = (trackName) => selectedTracks.includes(trackName);

  return (
    <div className="flex flex-col h-full bg-[#0f0f0f] rounded-xl border border-[#2a2a2a]">
      <div className="p-4 border-b border-[#2a2a2a]">
        <div className="flex items-center justify-between mb-3">
          <h3 className="text-sm font-semibold text-[#d4a574] uppercase tracking-wider">Music Library</h3>
          <span className="text-xs text-gray-500">{tracks.length} tracks</span>
        </div>
        
        {!musicFolder ? (
          isInIframe() ? (
            <div className="space-y-3">
              <div className="p-3 bg-amber-500/10 border border-amber-500/30 rounded-lg">
                <div className="flex items-start gap-2">
                  <AlertTriangle className="w-4 h-4 text-amber-500 mt-0.5 flex-shrink-0" />
                  <div>
                    <p className="text-sm text-amber-400 font-medium">Preview Mode</p>
                    <p className="text-xs text-amber-400/70 mt-1">
                      File access requires opening in a new tab.
                    </p>
                  </div>
                </div>
              </div>
              <Button 
                onClick={() => window.open(window.location.href, '_blank')}
                className="w-full bg-[#d4a574] hover:bg-[#c49464] text-black font-medium"
              >
                <ExternalLink className="w-4 h-4 mr-2" />
                Open in New Tab
              </Button>
            </div>
          ) : (
            <Button 
              onClick={connectFolder}
              disabled={isLoading}
              className="w-full bg-[#d4a574] hover:bg-[#c49464] text-black font-medium"
            >
              <FolderOpen className="w-4 h-4 mr-2" />
              {isLoading ? 'Scanning...' : 'Connect Music Folder'}
            </Button>
          )
        ) : (
          <div className="space-y-2">
            <div className="flex items-center gap-2">
              <div className="flex-1 px-3 py-2 bg-[#1a1a1a] rounded-lg text-sm text-gray-300 truncate">
                📁 {folderName}
              </div>
              <Button
                size="icon"
                variant="ghost"
                onClick={reconnectFolder}
                disabled={isLoading}
                className="text-gray-400 hover:text-white hover:bg-[#2a2a2a]"
              >
                <RefreshCw className={`w-4 h-4 ${isLoading ? 'animate-spin' : ''}`} />
              </Button>
            </div>
            <div className="relative">
              <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-gray-500" />
              <Input
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                placeholder="Search tracks..."
                className="pl-9 bg-[#1a1a1a] border-[#2a2a2a] text-white placeholder:text-gray-500"
              />
            </div>
          </div>
        )}
      </div>
      
      <ScrollArea className="flex-1">
        <div className="p-2 space-y-1">
          {filteredTracks.map((track, idx) => (
            <button
              key={idx}
              onClick={() => onTrackSelect?.(track)}
              className={`w-full flex items-center gap-3 px-3 py-2 rounded-lg text-left transition-all ${
                isSelected(track.name)
                  ? 'bg-[#d4a574]/20 text-[#d4a574]'
                  : 'text-gray-300 hover:bg-[#1a1a1a] hover:text-white'
              }`}
            >
              {selectionMode && isSelected(track.name) ? (
                <Check className="w-4 h-4 text-[#d4a574] flex-shrink-0" />
              ) : (
                <Music className="w-4 h-4 text-gray-500 flex-shrink-0" />
              )}
              <span className="truncate text-sm">{track.name}</span>
            </button>
          ))}
          
          {filteredTracks.length === 0 && tracks.length > 0 && (
            <div className="text-center py-8 text-gray-500 text-sm">
              No tracks match your search
            </div>
          )}
          
          {tracks.length === 0 && musicFolder && (
            <div className="text-center py-8 text-gray-500 text-sm">
              No supported audio files found
            </div>
          )}
        </div>
      </ScrollArea>
    </div>
  );
}