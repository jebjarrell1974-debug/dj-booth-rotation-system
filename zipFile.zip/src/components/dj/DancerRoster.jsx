import React, { useState } from 'react';
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { ScrollArea } from "@/components/ui/scroll-area";
import { Badge } from "@/components/ui/badge";
import { 
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";
import { UserPlus, Edit2, Trash2, Music, User } from 'lucide-react';

const DANCER_COLORS = [
  '#d4a574', '#e87d7d', '#7dd4e8', '#9b7de8', '#7de89b', 
  '#e8d47d', '#e87db5', '#7d9be8', '#e8a77d', '#7de8d4'
];

export default function DancerRoster({ 
  dancers, 
  onAddDancer, 
  onEditDancer, 
  onDeleteDancer,
  onSelectDancer,
  selectedDancerId 
}) {
  const [isAddOpen, setIsAddOpen] = useState(false);
  const [newDancerName, setNewDancerName] = useState('');
  const [editingDancer, setEditingDancer] = useState(null);
  const [isAdding, setIsAdding] = useState(false);

  const handleAdd = async () => {
    if (newDancerName.trim() && !isAdding) {
      setIsAdding(true);
      const color = DANCER_COLORS[dancers.length % DANCER_COLORS.length];
      
      try {
        await onAddDancer({ 
          name: newDancerName.trim(), 
          color, 
          playlist: [], 
          is_active: true 
        });
        // Wait a bit for the query to refresh
        await new Promise(resolve => setTimeout(resolve, 300));
        setNewDancerName('');
        setIsAddOpen(false);
      } catch (error) {
        console.error('Failed to add dancer:', error);
      } finally {
        setIsAdding(false);
      }
    }
  };

  const handleEdit = () => {
    if (editingDancer && editingDancer.name.trim()) {
      onEditDancer(editingDancer.id, { name: editingDancer.name });
      setEditingDancer(null);
    }
  };

  const activeDancers = dancers.filter(d => d.is_active);

  return (
    <div className="flex flex-col h-full bg-[#0f0f0f] rounded-xl border border-[#2a2a2a]">
      <div className="p-4 border-b border-[#2a2a2a]">
        <div className="flex items-center justify-between">
          <h3 className="text-sm font-semibold text-[#d4a574] uppercase tracking-wider">
            Dancer Roster
          </h3>
          <Dialog open={isAddOpen} onOpenChange={setIsAddOpen}>
            <DialogTrigger asChild>
              <Button size="sm" className="bg-[#d4a574] hover:bg-[#c49464] text-black">
                <UserPlus className="w-4 h-4 mr-1" />
                Add
              </Button>
            </DialogTrigger>
            <DialogContent className="bg-[#1a1a1a] border-[#2a2a2a] text-white">
              <DialogHeader>
                <DialogTitle>Add New Dancer</DialogTitle>
              </DialogHeader>
              <div className="space-y-4 pt-4">
                <Input
                  value={newDancerName}
                  onChange={(e) => setNewDancerName(e.target.value)}
                  placeholder="Stage name..."
                  className="bg-[#0f0f0f] border-[#2a2a2a]"
                  onKeyDown={(e) => e.key === 'Enter' && handleAdd()}
                  autoFocus
                />
                <Button 
                  onClick={handleAdd} 
                  disabled={isAdding || !newDancerName.trim()}
                  className="w-full bg-[#d4a574] hover:bg-[#c49464] text-black"
                >
                  {isAdding ? 'Adding...' : 'Add Dancer'}
                </Button>
              </div>
            </DialogContent>
          </Dialog>
        </div>
        <p className="text-xs text-gray-500 mt-1">{activeDancers.length} active</p>
      </div>
      
      <ScrollArea className="flex-1">
        <div className="p-2 space-y-1">
          {dancers.map((dancer) => (
            <div
              key={dancer.id}
              onClick={() => onSelectDancer?.(dancer)}
              className={`flex items-center gap-3 px-3 py-2 rounded-lg cursor-pointer transition-all ${
                selectedDancerId === dancer.id
                  ? 'bg-[#2a2a2a] ring-1 ring-[#d4a574]'
                  : 'hover:bg-[#1a1a1a]'
              } ${!dancer.is_active ? 'opacity-50' : ''}`}
            >
              <div 
                className="w-8 h-8 rounded-full flex items-center justify-center text-black font-bold text-sm"
                style={{ backgroundColor: dancer.color || '#d4a574' }}
              >
                {dancer.name.charAt(0).toUpperCase()}
              </div>
              
              <div className="flex-1 min-w-0">
                <p className="text-sm font-medium text-white truncate">{dancer.name}</p>
                <div className="flex items-center gap-1 text-xs text-gray-500">
                  <Music className="w-3 h-3" />
                  <span>{dancer.playlist?.length || 0} songs</span>
                </div>
              </div>
              
              <div className="flex items-center gap-1">
                <Dialog>
                  <DialogTrigger asChild>
                    <Button
                      size="icon"
                      variant="ghost"
                      className="w-7 h-7 text-gray-500 hover:text-white hover:bg-[#2a2a2a]"
                      onClick={(e) => {
                        e.stopPropagation();
                        setEditingDancer({ ...dancer });
                      }}
                    >
                      <Edit2 className="w-3 h-3" />
                    </Button>
                  </DialogTrigger>
                  <DialogContent className="bg-[#1a1a1a] border-[#2a2a2a] text-white">
                    <DialogHeader>
                      <DialogTitle>Edit Dancer</DialogTitle>
                    </DialogHeader>
                    <div className="space-y-4 pt-4">
                      <Input
                        value={editingDancer?.name || ''}
                        onChange={(e) => setEditingDancer(prev => ({ ...prev, name: e.target.value }))}
                        placeholder="Stage name..."
                        className="bg-[#0f0f0f] border-[#2a2a2a]"
                      />
                      <Button onClick={handleEdit} className="w-full bg-[#d4a574] hover:bg-[#c49464] text-black">
                        Save Changes
                      </Button>
                    </div>
                  </DialogContent>
                </Dialog>
                
                <Button
                  size="icon"
                  variant="ghost"
                  className="w-7 h-7 text-gray-500 hover:text-red-400 hover:bg-[#2a2a2a]"
                  onClick={(e) => {
                    e.stopPropagation();
                    onDeleteDancer(dancer.id);
                  }}
                >
                  <Trash2 className="w-3 h-3" />
                </Button>
              </div>
            </div>
          ))}
          
          {dancers.length === 0 && (
            <div className="text-center py-8">
              <User className="w-8 h-8 mx-auto text-gray-600 mb-2" />
              <p className="text-gray-500 text-sm">No dancers added yet</p>
            </div>
          )}
        </div>
      </ScrollArea>
    </div>
  );
}