import React, { useState } from 'react';
import { Button } from "@/components/ui/button";
import { ScrollArea } from "@/components/ui/scroll-area";
import { Badge } from "@/components/ui/badge";
import { Music, X, Shuffle, Save, AlertCircle } from 'lucide-react';

export default function PlaylistEditor({
  dancer,
  tracks,
  onSave,
  onClose
}) {
  const [playlist, setPlaylist] = useState(dancer?.playlist || []);

  const addTrack = (trackName) => {
    if (!playlist.includes(trackName)) {
      setPlaylist([...playlist, trackName]);
    }
  };

  const removeTrack = (trackName) => {
    setPlaylist(playlist.filter(t => t !== trackName));
  };

  const randomize = () => {
    const count = Math.min(10, tracks.length);
    const shuffled = [...tracks].sort(() => Math.random() - 0.5);
    setPlaylist(shuffled.slice(0, count).map(t => t.name));
  };

  const handleSave = () => {
    onSave(playlist);
    onClose();
  };

  if (!dancer) return null;

  return (
    <div className="fixed inset-0 bg-black/80 backdrop-blur-sm z-50 flex items-center justify-center p-4">
      <div className="bg-[#0f0f0f] rounded-xl border border-[#2a2a2a] w-full max-w-2xl max-h-[80vh] flex flex-col">
        <div className="p-4 border-b border-[#2a2a2a] flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div 
              className="w-10 h-10 rounded-full flex items-center justify-center text-black font-bold"
              style={{ backgroundColor: dancer.color || '#d4a574' }}
            >
              {dancer.name.charAt(0).toUpperCase()}
            </div>
            <div>
              <h2 className="text-lg font-semibold text-white">{dancer.name}'s Playlist</h2>
              <p className="text-xs text-gray-500">{playlist.length} songs - App will auto-select 2 per set</p>
            </div>
          </div>
          <Button
            size="icon"
            variant="ghost"
            onClick={onClose}
            className="text-gray-400 hover:text-white"
          >
            <X className="w-5 h-5" />
          </Button>
        </div>

        <div className="flex-1 flex overflow-hidden">
          {/* Selected Songs */}
          <div className="w-1/3 border-r border-[#2a2a2a] p-4 flex flex-col">
            <h3 className="text-sm font-semibold text-[#d4a574] uppercase tracking-wider mb-3">
              Current Playlist
            </h3>

            <ScrollArea className="flex-1 mb-4">
              <div className="space-y-2">
                {playlist.map((songName, idx) => (
                  <div
                    key={idx}
                    className="p-3 rounded-lg border border-[#d4a574]/30 bg-[#d4a574]/10"
                  >
                    <div className="flex items-center justify-between">
                      <div className="flex-1 mr-2">
                        <p className="text-xs text-gray-500 mb-1">#{idx + 1}</p>
                        <span className="text-sm text-white truncate block">
                          {songName}
                        </span>
                      </div>
                      <Button
                        size="icon"
                        variant="ghost"
                        className="w-6 h-6 text-gray-500 hover:text-red-400 flex-shrink-0"
                        onClick={() => removeTrack(songName)}
                      >
                        <X className="w-3 h-3" />
                      </Button>
                    </div>
                  </div>
                ))}
                
                {playlist.length === 0 && (
                  <div className="p-3 bg-[#1a1a1a] border border-dashed border-[#2a2a2a] rounded-lg text-center">
                    <span className="text-sm text-gray-600">No songs selected</span>
                  </div>
                )}
              </div>
            </ScrollArea>

            {playlist.length === 0 && (
              <div className="mb-4 p-3 bg-amber-500/10 border border-amber-500/30 rounded-lg">
                <div className="flex items-start gap-2">
                  <AlertCircle className="w-4 h-4 text-amber-500 mt-0.5 flex-shrink-0" />
                  <p className="text-xs text-amber-400">
                    Empty playlists will use random tracks from library
                  </p>
                </div>
              </div>
            )}

            <div className="space-y-2">
              <Button
                variant="outline"
                className="w-full border-[#2a2a2a] text-gray-300 hover:bg-[#2a2a2a]"
                onClick={randomize}
                disabled={tracks.length === 0}
              >
                <Shuffle className="w-4 h-4 mr-2" />
                Add 10 Random
              </Button>
              <Button
                className="w-full bg-[#d4a574] hover:bg-[#c49464] text-black"
                onClick={handleSave}
              >
                <Save className="w-4 h-4 mr-2" />
                Save Playlist
              </Button>
            </div>
          </div>

          {/* Track Library */}
          <div className="flex-1 flex flex-col">
            <div className="p-4 border-b border-[#2a2a2a]">
              <h3 className="text-sm font-semibold text-gray-400">
                Available Tracks ({tracks.length})
              </h3>
            </div>
            <ScrollArea className="flex-1">
              <div className="p-2 space-y-1">
                {tracks.map((track, idx) => {
                  const isSelected = playlist.includes(track.name);
                  return (
                    <button
                      key={idx}
                      onClick={() => !isSelected && addTrack(track.name)}
                      disabled={isSelected}
                      className={`w-full flex items-center gap-3 px-3 py-2 rounded-lg text-left transition-all ${
                        isSelected
                          ? 'bg-[#d4a574]/20 text-[#d4a574] cursor-default'
                          : 'text-gray-300 hover:bg-[#1a1a1a] hover:text-white'
                      }`}
                    >
                      <Music className={`w-4 h-4 flex-shrink-0 ${isSelected ? 'text-[#d4a574]' : 'text-gray-500'}`} />
                      <span className="truncate text-sm">{track.name}</span>
                      {isSelected && (
                        <Badge className="ml-auto bg-[#d4a574] text-black text-xs">
                          ✓
                        </Badge>
                      )}
                    </button>
                  );
                })}
              </div>
            </ScrollArea>
          </div>
        </div>
      </div>
    </div>
  );
}