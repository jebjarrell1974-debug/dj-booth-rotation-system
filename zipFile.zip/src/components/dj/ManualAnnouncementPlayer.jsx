import React, { useState } from 'react';
import { base44 } from '@/api/base44Client';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { ScrollArea } from "@/components/ui/scroll-area";
import { Upload, Play, Trash2, Mic } from 'lucide-react';
import { toast } from 'sonner';

export default function ManualAnnouncementPlayer({ onPlay }) {
  const [uploading, setUploading] = useState(false);
  const [customName, setCustomName] = useState('');
  const queryClient = useQueryClient();

  // Fetch saved announcements
  const { data: announcements = [] } = useQuery({
    queryKey: ['manual-announcements'],
    queryFn: async () => {
      const all = await base44.entities.AnnouncementCache.list();
      return all.filter(a => a.type === 'manual' || !a.type);
    }
  });

  const deleteMutation = useMutation({
    mutationFn: (id) => base44.entities.AnnouncementCache.delete(id),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['manual-announcements'] });
      toast.success('Announcement deleted');
    }
  });

  const handleFileUpload = async (e) => {
    const file = e.target.files?.[0];
    if (!file) return;

    if (!file.type.startsWith('audio/')) {
      toast.error('Please upload an audio file');
      return;
    }

    setUploading(true);
    try {
      const { file_url } = await base44.integrations.Core.UploadFile({ file });
      
      const name = customName.trim() || file.name;
      
      await base44.entities.AnnouncementCache.create({
        cache_key: `manual-${Date.now()}-${name}`,
        audio_url: file_url,
        script: name,
        type: 'manual'
      });

      queryClient.invalidateQueries({ queryKey: ['manual-announcements'] });
      toast.success('Announcement uploaded');
      setCustomName('');
    } catch (error) {
      console.error('Upload error:', error);
      toast.error('Failed to upload announcement');
    } finally {
      setUploading(false);
    }
  };

  const handlePlay = async (announcement) => {
    if (onPlay) {
      await onPlay(announcement.audio_url);
      toast.success(`Playing: ${announcement.script}`);
    }
  };

  return (
    <div className="h-full flex flex-col">
      {/* Upload Section */}
      <div className="bg-[#1a1a1a] rounded-lg border border-[#2a2a2a] p-4 mb-4">
        <h3 className="text-sm font-semibold text-[#d4a574] uppercase tracking-wider mb-3">
          Upload Announcement / Ad
        </h3>
        
        <div className="space-y-3">
          <Input
            placeholder="Custom name (optional)"
            value={customName}
            onChange={(e) => setCustomName(e.target.value)}
            className="bg-[#0a0a0a] border-[#2a2a2a]"
          />
          
          <label className="block">
            <Button
              as="span"
              className="w-full bg-[#d4a574] hover:bg-[#c4956a] text-black cursor-pointer"
              disabled={uploading}
            >
              <Upload className="w-4 h-4 mr-2" />
              {uploading ? 'Uploading...' : 'Upload Audio File'}
            </Button>
            <input
              type="file"
              accept="audio/*"
              onChange={handleFileUpload}
              className="hidden"
              disabled={uploading}
            />
          </label>
          
          <p className="text-xs text-gray-500">
            Upload MP3, WAV, or other audio files for announcements and advertisements
          </p>
        </div>
      </div>

      {/* Announcements Library */}
      <div className="flex-1 bg-[#1a1a1a] rounded-lg border border-[#2a2a2a] p-4 flex flex-col">
        <h3 className="text-sm font-semibold text-[#d4a574] uppercase tracking-wider mb-3">
          Announcements Library ({announcements.length})
        </h3>
        
        <ScrollArea className="flex-1">
          <div className="space-y-2">
            {announcements.length === 0 ? (
              <div className="text-center py-12 text-gray-500">
                <Mic className="w-12 h-12 mx-auto mb-3 text-gray-700" />
                <p className="text-sm">No announcements uploaded yet</p>
              </div>
            ) : (
              announcements.map((announcement) => (
                <div
                  key={announcement.id}
                  className="flex items-center gap-3 bg-[#0f0f0f] rounded-lg p-3 border border-[#2a2a2a] hover:border-[#d4a574]/50 transition-colors"
                >
                  <div className="flex-1 min-w-0">
                    <p className="text-sm text-white truncate">{announcement.script}</p>
                  </div>
                  
                  <div className="flex items-center gap-2">
                    <Button
                      size="sm"
                      onClick={() => handlePlay(announcement)}
                      className="bg-green-600 hover:bg-green-700 text-white"
                    >
                      <Play className="w-4 h-4" />
                    </Button>
                    
                    <Button
                      size="sm"
                      variant="ghost"
                      onClick={() => deleteMutation.mutate(announcement.id)}
                      className="text-red-400 hover:text-red-300 hover:bg-red-900/20"
                    >
                      <Trash2 className="w-4 h-4" />
                    </Button>
                  </div>
                </div>
              ))
            )}
          </div>
        </ScrollArea>
      </div>
    </div>
  );
}