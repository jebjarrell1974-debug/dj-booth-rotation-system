import React, { useState } from 'react';
import { DragDropContext, Droppable, Draggable } from '@hello-pangea/dnd';
import { Button } from "@/components/ui/button";
import { ScrollArea } from "@/components/ui/scroll-area";
import { Input } from "@/components/ui/input";
import { Music2, X, Save, Search, Play, ChevronUp, ChevronDown } from 'lucide-react';
import { toast } from 'sonner';

const MAX_PLAYLIST_SONGS = 50; // Dancers can build large playlists

export default function RotationPlaylistManager({ 
  dancers, 
  rotation, 
  tracks,
  onSavePlaylists,
  onAddToRotation,
  onRemoveFromRotation,
  onStartRotation,
  isRotationActive,
  onMoveUp,
  onMoveDown
}) {
  const [searchQuery, setSearchQuery] = useState('');
  const [playlists, setPlaylists] = useState(() => {
    const initial = {};
    rotation.forEach(dancerId => {
      const dancer = dancers.find(d => d.id === dancerId);
      if (dancer) {
        initial[dancerId] = dancer.playlist || [];
      }
    });
    return initial;
  });

  const rotationDancers = rotation.map(id => dancers.find(d => d.id === id)).filter(Boolean);
  const availableDancers = dancers.filter(d => d.is_active && !rotation.includes(d.id));

  const filteredTracks = tracks.filter(track =>
    track.name.toLowerCase().includes(searchQuery.toLowerCase())
  );

  const handleDragEnd = (result) => {
    const { source, destination } = result;

    if (!destination) return;

    // Dragging from library to a dancer's playlist
    if (source.droppableId === 'library' && destination.droppableId.startsWith('dancer-')) {
      const dancerId = destination.droppableId.replace('dancer-', '');
      const track = filteredTracks[source.index];
      
      const currentPlaylist = playlists[dancerId] || [];
      
      // Check if playlist is full
      if (currentPlaylist.length >= MAX_PLAYLIST_SONGS) {
        toast.error(`Playlist is full (${MAX_PLAYLIST_SONGS} songs max)`);
        return;
      }

      // Check if song already in playlist
      if (currentPlaylist.includes(track.name)) {
        toast.error('Song already in playlist');
        return;
      }

      setPlaylists({
        ...playlists,
        [dancerId]: [...currentPlaylist, track.name]
      });
    }

    // Reordering within a dancer's playlist
    if (source.droppableId === destination.droppableId && source.droppableId.startsWith('dancer-')) {
      const dancerId = source.droppableId.replace('dancer-', '');
      const currentPlaylist = [...(playlists[dancerId] || [])];
      const [removed] = currentPlaylist.splice(source.index, 1);
      currentPlaylist.splice(destination.index, 0, removed);
      
      setPlaylists({
        ...playlists,
        [dancerId]: currentPlaylist
      });
    }
  };

  const removeSong = (dancerId, songIndex) => {
    const currentPlaylist = [...(playlists[dancerId] || [])];
    currentPlaylist.splice(songIndex, 1);
    setPlaylists({
      ...playlists,
      [dancerId]: currentPlaylist
    });
  };

  const handleSave = () => {
    onSavePlaylists(playlists);
    toast.success('Playlists saved successfully');
  };

  return (
    <div className="flex h-full bg-[#0f0f0f] rounded-xl border border-[#2a2a2a]">
      <DragDropContext onDragEnd={handleDragEnd}>
        {/* Left Side - Music Library */}
        <div className="w-1/2 border-r border-[#2a2a2a] flex flex-col">
          <div className="p-4 border-b border-[#2a2a2a]">
            <h3 className="text-sm font-semibold text-[#d4a574] uppercase tracking-wider mb-3">
              Music Library
            </h3>
            <div className="relative">
              <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 w-4 h-4 text-gray-500" />
              <Input
                placeholder="Search tracks..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="pl-9 bg-[#1a1a1a] border-[#2a2a2a]"
              />
            </div>
          </div>

          <Droppable droppableId="library" isDropDisabled={true}>
            {(provided) => (
              <ScrollArea className="flex-1">
                <div
                  ref={provided.innerRef}
                  {...provided.droppableProps}
                  className="p-2"
                >
                  {filteredTracks.map((track, index) => (
                    <Draggable key={track.name} draggableId={track.name} index={index}>
                      {(provided, snapshot) => (
                        <div
                          ref={provided.innerRef}
                          {...provided.draggableProps}
                          {...provided.dragHandleProps}
                          className={`flex items-center gap-2 px-3 py-2 mb-1 rounded-lg transition-all cursor-grab active:cursor-grabbing ${
                            snapshot.isDragging
                              ? 'bg-[#d4a574]/20 ring-2 ring-[#d4a574]'
                              : 'bg-[#1a1a1a] hover:bg-[#2a2a2a]'
                          }`}
                        >
                          <Music2 className="w-4 h-4 text-gray-500 flex-shrink-0" />
                          <span className="text-sm text-white truncate flex-1">{track.name}</span>
                        </div>
                      )}
                    </Draggable>
                  ))}
                  {provided.placeholder}
                </div>
              </ScrollArea>
            )}
          </Droppable>
        </div>

        {/* Right Side - Dancer Playlists */}
        <div className="w-1/2 flex flex-col">
          <div className="p-4 border-b border-[#2a2a2a]">
            <div className="flex items-center justify-between mb-3">
            <div>
              <h3 className="text-sm font-semibold text-[#d4a574] uppercase tracking-wider">
                Rotation Playlists
              </h3>
              <p className="text-xs text-gray-500 mt-0.5">
                {rotationDancers.length} dancers in rotation
              </p>
            </div>
            <Button
              onClick={handleSave}
              className="bg-[#d4a574] hover:bg-[#c4956a] text-black"
            >
              <Save className="w-4 h-4 mr-2" />
              Save All
            </Button>
            </div>
            
            {/* Add Dancers to Rotation */}
            {availableDancers.length > 0 && (
              <div className="flex flex-wrap gap-2 pt-3 border-t border-[#2a2a2a]">
                <p className="text-xs text-gray-500 w-full mb-1">Add to rotation:</p>
                {availableDancers.map(dancer => (
                  <Button
                    key={dancer.id}
                    size="sm"
                    variant="outline"
                    className="border-[#2a2a2a] text-gray-300 hover:bg-[#2a2a2a] hover:text-white text-xs"
                    onClick={() => onAddToRotation?.(dancer.id)}
                  >
                    <div 
                      className="w-4 h-4 rounded-full flex items-center justify-center text-black font-bold text-xs mr-1.5"
                      style={{ backgroundColor: dancer.color || '#d4a574' }}
                    >
                      {dancer.name.charAt(0).toUpperCase()}
                    </div>
                    {dancer.name}
                  </Button>
                ))}
              </div>
            )}
          </div>

          <ScrollArea className="flex-1">
            <div className="p-4 space-y-4">
              {rotationDancers.map((dancer, index) => {
                const dancerPlaylist = playlists[dancer.id] || [];
                
                return (
                  <div key={dancer.id} className="bg-[#1a1a1a] rounded-lg border border-[#2a2a2a] overflow-hidden">
                    <div className="px-4 py-3 border-b border-[#2a2a2a] flex items-center gap-3">
                      <div
                        className="w-8 h-8 rounded-full flex items-center justify-center text-black font-bold text-sm"
                        style={{ backgroundColor: dancer.color || '#d4a574' }}
                      >
                        {dancer.name.charAt(0).toUpperCase()}
                      </div>
                      <div className="flex-1">
                        <p className="text-white font-semibold text-sm">{dancer.name}</p>
                        <p className="text-xs text-gray-500">
                          {dancerPlaylist.length > 0 
                            ? `${dancerPlaylist.length} songs in playlist • 2 will be selected`
                            : 'Will use random songs'}
                        </p>
                      </div>
                      <div className="flex items-center gap-1">
                        <Button
                          size="icon"
                          variant="ghost"
                          className="w-7 h-7 text-gray-500 hover:text-white hover:bg-[#2a2a2a]"
                          onClick={() => onMoveUp?.(index)}
                          disabled={index === 0}
                        >
                          <ChevronUp className="w-4 h-4" />
                        </Button>
                        <Button
                          size="icon"
                          variant="ghost"
                          className="w-7 h-7 text-gray-500 hover:text-white hover:bg-[#2a2a2a]"
                          onClick={() => onMoveDown?.(index)}
                          disabled={index === rotationDancers.length - 1}
                        >
                          <ChevronDown className="w-4 h-4" />
                        </Button>
                        <Button
                          size="icon"
                          variant="ghost"
                          className="w-7 h-7 text-gray-500 hover:text-red-400 hover:bg-[#2a2a2a]"
                          onClick={() => onRemoveFromRotation?.(dancer.id)}
                        >
                          <X className="w-4 h-4" />
                        </Button>
                      </div>
                    </div>

                    <div className="p-3">
                      {dancerPlaylist.length === 0 ? (
                        <div className="flex flex-col items-center justify-center h-[80px] text-center border-2 border-dashed border-[#2a2a2a] rounded-lg px-3">
                          <p className="text-sm text-gray-500 mb-1">Will play 2 random songs from library</p>
                          <p className="text-xs text-gray-600">Go to Dancers tab to build a custom playlist</p>
                        </div>
                      ) : (
                        <div className="flex flex-col items-center justify-center h-[80px] text-center border-2 border-dashed border-[#2a2a2a] rounded-lg px-3">
                          <p className="text-sm text-white mb-1">Will play 2 random songs from playlist</p>
                          <p className="text-xs text-gray-500">{dancerPlaylist.length} songs available</p>
                          <p className="text-xs text-gray-600 mt-1">Go to Dancers tab to edit playlist</p>
                        </div>
                      )}
                    </div>
                  </div>
                );
              })}

              {rotationDancers.length === 0 && (
                <div className="text-center py-12 text-gray-500">
                  <Music2 className="w-12 h-12 mx-auto mb-3 text-gray-700" />
                  <p className="text-sm">No dancers in rotation</p>
                </div>
              )}
            </div>
          </ScrollArea>
        </div>
      </DragDropContext>
    </div>
  );
}