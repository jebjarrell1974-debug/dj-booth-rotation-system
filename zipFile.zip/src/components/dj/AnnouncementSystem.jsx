import React, { useState, useCallback, useEffect } from 'react';
import { Button } from "@/components/ui/button";
import { Progress } from "@/components/ui/progress";
import { Badge } from "@/components/ui/badge";
import { Mic, Download, Wifi, WifiOff, Loader2, Check, AlertCircle } from 'lucide-react';
import { base44 } from '@/api/base44Client';

// IndexedDB helper functions
const DB_NAME = 'djAnnouncementsDB';
const STORE_NAME = 'announcements';

const openDB = () => {
  return new Promise((resolve, reject) => {
    const request = indexedDB.open(DB_NAME, 1);
    request.onerror = () => reject(request.error);
    request.onsuccess = () => resolve(request.result);
    request.onupgradeneeded = (event) => {
      const db = event.target.result;
      if (!db.objectStoreNames.contains(STORE_NAME)) {
        db.createObjectStore(STORE_NAME, { keyPath: 'key' });
      }
    };
  });
};

const getCachedAnnouncement = async (key) => {
  const db = await openDB();
  return new Promise((resolve, reject) => {
    const tx = db.transaction(STORE_NAME, 'readonly');
    const store = tx.objectStore(STORE_NAME);
    const request = store.get(key);
    request.onerror = () => reject(request.error);
    request.onsuccess = () => resolve(request.result?.audioBlob);
  });
};

const cacheAnnouncement = async (key, audioBlob) => {
  const db = await openDB();
  return new Promise((resolve, reject) => {
    const tx = db.transaction(STORE_NAME, 'readwrite');
    const store = tx.objectStore(STORE_NAME);
    const request = store.put({ key, audioBlob, timestamp: Date.now() });
    request.onerror = () => reject(request.error);
    request.onsuccess = () => resolve();
  });
};

const clearAnnouncementCache = async () => {
  const db = await openDB();
  return new Promise((resolve, reject) => {
    const tx = db.transaction(STORE_NAME, 'readwrite');
    const store = tx.objectStore(STORE_NAME);
    const request = store.clear();
    request.onerror = () => reject(request.error);
    request.onsuccess = () => resolve();
  });
};

// Language bank for announcements
const LANGUAGE_BANK = {
  greetings: [
    "Gentlemen...",
    "Eyes up...",
    "Your attention, please...",
    "Now arriving...",
    "Making her way to the stage..."
  ],
  appreciation: [
    "Show her some love...",
    "She deserves your appreciation...",
    "Let her know you're watching...",
    "A warm welcome for..."
  ],
  round2: [
    "Staying on stage for round two...",
    "Continuing her performance...",
    "She's not done yet...",
    "Her second song..."
  ],
  outros: [
    "That was...",
    "Thank you...",
    "A round of applause for...",
    "Showing appreciation for..."
  ],
  transitions: [
    "And now...",
    "Next to grace the stage...",
    "Following that beautiful performance...",
    "The stage is ready for..."
  ]
};

const ANNOUNCEMENT_TYPES = {
  INTRO: 'intro',
  ROUND2: 'round2',
  OUTRO: 'outro',
  TRANSITION: 'transition'
};

const AnnouncementSystem = React.forwardRef((props, ref) => {
  const {
    dancers,
    rotation,
    currentDancerIndex,
    onPlay,
    elevenLabsApiKey,
    openaiApiKey,
    hideUI = false
  } = props;

  const [isOnline, setIsOnline] = useState(navigator.onLine);
  const [cacheStatus, setCacheStatus] = useState({});
  const [isPreCaching, setIsPreCaching] = useState(false);
  const [preCacheProgress, setPreCacheProgress] = useState(0);
  const [generatingType, setGeneratingType] = useState(null);

  useEffect(() => {
    const handleOnline = () => setIsOnline(true);
    const handleOffline = () => setIsOnline(false);
    window.addEventListener('online', handleOnline);
    window.addEventListener('offline', handleOffline);
    
    // Clear old IndexedDB cache on mount
    clearAnnouncementCache().catch(err => console.log('Cache cleared:', err));
    
    return () => {
      window.removeEventListener('online', handleOnline);
      window.removeEventListener('offline', handleOffline);
    };
  }, []);

  const generateScript = useCallback(async (type, dancerName, nextDancerName = null) => {
    const randomPhrase = (arr) => arr[Math.floor(Math.random() * arr.length)];
    
    let prompt = '';
    switch (type) {
      case ANNOUNCEMENT_TYPES.INTRO:
        prompt = `Write a brief, intimate strip club DJ announcement (max 20 words) to introduce a dancer named "${dancerName}" to the stage. Use phrases like "${randomPhrase(LANGUAGE_BANK.greetings)}" and "${randomPhrase(LANGUAGE_BANK.appreciation)}". Keep it classy and controlled, no arena hype, no "make some noise". Just smooth and inviting.`;
        break;
      case ANNOUNCEMENT_TYPES.ROUND2:
        prompt = `Write a very brief strip club DJ announcement (max 15 words) for "${dancerName}"'s second song. Use a phrase like "${randomPhrase(LANGUAGE_BANK.round2)}". Keep it minimal and smooth.`;
        break;
      case ANNOUNCEMENT_TYPES.OUTRO:
        prompt = `Write a brief strip club DJ thank you announcement (max 15 words) for "${dancerName}" finishing her set. Use a phrase like "${randomPhrase(LANGUAGE_BANK.outros)}". Classy and appreciative.`;
        break;
      case ANNOUNCEMENT_TYPES.TRANSITION:
        prompt = `Write a strip club DJ transition announcement (max 25 words) thanking "${dancerName}" and introducing "${nextDancerName}" who is walking to the stage. This should be timed for a 16-count runway walk. Use phrases like "${randomPhrase(LANGUAGE_BANK.outros)}" for the outgoing dancer and "${randomPhrase(LANGUAGE_BANK.transitions)}" for the incoming. Make it one smooth, flowing announcement.`;
        break;
    }

    const response = await base44.integrations.Core.InvokeLLM({
      prompt,
      response_json_schema: {
        type: "object",
        properties: {
          script: { type: "string" }
        }
      }
    });
    
    return response.script;
  }, []);

  const generateAudio = useCallback(async (script) => {
    const apiKey = elevenLabsApiKey;
    if (!apiKey) {
      throw new Error('ElevenLabs API key not configured in components/apiConfig.js');
    }

    // Import voice ID from config
    const { API_CONFIG } = await import('@/components/apiConfig');
    const voiceId = API_CONFIG.elevenLabsVoiceId || '21m00Tcm4TlvDq8ikWAM';
    
    try {
      const response = await fetch(`https://api.elevenlabs.io/v1/text-to-speech/${voiceId}`, {
        method: 'POST',
        headers: {
          'Accept': 'audio/mpeg',
          'Content-Type': 'application/json',
          'xi-api-key': apiKey
        },
        body: JSON.stringify({
          text: script,
          model_id: 'eleven_monolingual_v1',
          voice_settings: {
            stability: 0.5,
            similarity_boost: 0.75
          }
        })
      });

      if (!response.ok) {
        const status = response.status;
        if (status === 401) {
          throw new Error('Invalid ElevenLabs API key - check settings');
        } else if (status === 429) {
          throw new Error('Rate limit exceeded. Wait a moment and try again.');
        }
        throw new Error(`Failed to generate audio (status ${status})`);
      }

      return await response.blob();
    } catch (error) {
      if (error.message.includes('Rate limit')) {
        throw error;
      }
      throw error;
    }
  }, [elevenLabsApiKey]);

  const getAnnouncementKey = (type, dancerName, nextDancerName = null) => {
    return `${type}-${dancerName}${nextDancerName ? `-${nextDancerName}` : ''}`;
  };

  const getOrGenerateAnnouncement = useCallback(async (type, dancerName, nextDancerName = null) => {
    const key = getAnnouncementKey(type, dancerName, nextDancerName);
    
    // Check database first
    const dbCached = await base44.entities.AnnouncementCache.filter({ cache_key: key });
    if (dbCached.length > 0) {
      console.log(`✅ Found cached announcement in database: ${key}`);
      setCacheStatus(prev => ({ ...prev, [key]: true }));
      return dbCached[0].audio_url;
    }

    // Check IndexedDB as fallback
    const localCached = await getCachedAnnouncement(key);
    if (localCached) {
      console.log(`✅ Found cached announcement in IndexedDB: ${key}`);
      return URL.createObjectURL(localCached);
    }

    // Generate new announcement
    console.log(`🎙️ Generating new announcement: ${key}`);
    setGeneratingType(type);
    const script = await generateScript(type, dancerName, nextDancerName);
    const audioBlob = await generateAudio(script);
    
    // Upload to permanent storage
    const file = new File([audioBlob], `${key}.mp3`, { type: 'audio/mpeg' });
    const { file_url } = await base44.integrations.Core.UploadFile({ file });
    
    // Save to database
    await base44.entities.AnnouncementCache.create({
      cache_key: key,
      audio_url: file_url,
      script: script,
      type: type
    });
    
    // Also cache locally for offline use
    await cacheAnnouncement(key, audioBlob);
    setCacheStatus(prev => ({ ...prev, [key]: true }));
    setGeneratingType(null);
    
    console.log(`✅ Cached announcement to database: ${key}`);
    return file_url;
  }, [generateScript, generateAudio]);

  const playAnnouncement = useCallback(async (type, dancerName, nextDancerName = null) => {
    try {
      console.log(`📢 AnnouncementSystem: Generating ${type} for ${dancerName}`);
      const audioUrl = await getOrGenerateAnnouncement(type, dancerName, nextDancerName);
      console.log(`📢 AnnouncementSystem: Got audio URL, playing...`);
      await onPlay?.(audioUrl);
      console.log(`📢 AnnouncementSystem: Playback complete`);
    } catch (error) {
      console.error(`❌ AnnouncementSystem Error:`, error.message);
      alert(`Announcement Error: ${error.message}\n\nCheck your API keys in Settings.`);
      throw error;
    }
  }, [getOrGenerateAnnouncement, onPlay]);

  // Expose methods to parent via ref
  React.useImperativeHandle(ref, () => ({
    playAutoAnnouncement: async (type, currentDancerName, nextDancerName = null) => {
      await playAnnouncement(type, currentDancerName, nextDancerName);
    }
  }));

  const preCacheAll = useCallback(async () => {
    if (!isOnline) return;
    
    setIsPreCaching(true);
    setPreCacheProgress(0);
    
    const rotationDancers = rotation.map(id => dancers.find(d => d.id === id)).filter(Boolean);
    const totalAnnouncements = rotationDancers.length * 3 + (rotationDancers.length > 1 ? rotationDancers.length : 0);
    let completed = 0;

    try {
      for (let i = 0; i < rotationDancers.length; i++) {
        const dancer = rotationDancers[i];
        const nextDancer = rotationDancers[(i + 1) % rotationDancers.length];

        // Generate intro
        await getOrGenerateAnnouncement(ANNOUNCEMENT_TYPES.INTRO, dancer.name);
        completed++;
        setPreCacheProgress((completed / totalAnnouncements) * 100);
        await new Promise(resolve => setTimeout(resolve, 1500)); // 1.5s delay between calls

        // Generate round 2
        await getOrGenerateAnnouncement(ANNOUNCEMENT_TYPES.ROUND2, dancer.name);
        completed++;
        setPreCacheProgress((completed / totalAnnouncements) * 100);
        await new Promise(resolve => setTimeout(resolve, 1500));

        // Generate outro
        await getOrGenerateAnnouncement(ANNOUNCEMENT_TYPES.OUTRO, dancer.name);
        completed++;
        setPreCacheProgress((completed / totalAnnouncements) * 100);
        await new Promise(resolve => setTimeout(resolve, 1500));

        // Generate transition (if more than one dancer)
        if (rotationDancers.length > 1) {
          await getOrGenerateAnnouncement(ANNOUNCEMENT_TYPES.TRANSITION, dancer.name, nextDancer.name);
          completed++;
          setPreCacheProgress((completed / totalAnnouncements) * 100);
          await new Promise(resolve => setTimeout(resolve, 1500));
        }
      }
    } catch (error) {
      console.error('Pre-cache failed:', error.message);
      alert(`Pre-caching stopped: ${error.message}`);
    } finally {
      setIsPreCaching(false);
    }
  }, [isOnline, rotation, dancers, getOrGenerateAnnouncement]);

  const currentDancer = rotation[currentDancerIndex] 
    ? dancers.find(d => d.id === rotation[currentDancerIndex])
    : null;
  
  const nextDancer = rotation[(currentDancerIndex + 1) % rotation.length]
    ? dancers.find(d => d.id === rotation[(currentDancerIndex + 1) % rotation.length])
    : null;

  if (hideUI) {
    return null;
  }

  return (
    <div className="bg-[#0f0f0f] rounded-xl border border-[#2a2a2a] p-4">
      <div className="flex items-center justify-between mb-4">
        <div className="flex items-center gap-2">
          <Mic className="w-4 h-4 text-[#d4a574]" />
          <h3 className="text-sm font-semibold text-[#d4a574] uppercase tracking-wider">
            Announcements
          </h3>
        </div>
        <Badge 
          variant="outline" 
          className={isOnline ? 'border-green-500 text-green-400' : 'border-red-500 text-red-400'}
        >
          {isOnline ? <Wifi className="w-3 h-3 mr-1" /> : <WifiOff className="w-3 h-3 mr-1" />}
          {isOnline ? 'Online' : 'Offline'}
        </Badge>
      </div>

      {/* Pre-cache Button */}
      <Button
        onClick={preCacheAll}
        disabled={!isOnline || isPreCaching || rotation.length === 0}
        className="w-full mb-4 bg-[#1a1a1a] hover:bg-[#2a2a2a] text-white border border-[#2a2a2a]"
      >
        {isPreCaching ? (
          <>
            <Loader2 className="w-4 h-4 mr-2 animate-spin" />
            Caching... {Math.round(preCacheProgress)}%
          </>
        ) : (
          <>
            <Download className="w-4 h-4 mr-2" />
            Pre-Cache All Announcements
          </>
        )}
      </Button>

      {isPreCaching && (
        <Progress value={preCacheProgress} className="mb-4" />
      )}

      {/* Quick Announcement Buttons */}
      {currentDancer && (
        <div className="space-y-2">
          <p className="text-xs text-gray-500 uppercase tracking-wider">Quick Announce</p>
          
          <div className="grid grid-cols-2 gap-2">
            <Button
              size="sm"
              variant="outline"
              className="border-[#2a2a2a] text-gray-300 hover:bg-[#2a2a2a] hover:text-white justify-start"
              onClick={() => playAnnouncement(ANNOUNCEMENT_TYPES.INTRO, currentDancer.name)}
              disabled={generatingType === ANNOUNCEMENT_TYPES.INTRO}
            >
              {generatingType === ANNOUNCEMENT_TYPES.INTRO ? (
                <Loader2 className="w-3 h-3 mr-2 animate-spin" />
              ) : (
                <Mic className="w-3 h-3 mr-2" />
              )}
              Intro
            </Button>
            
            <Button
              size="sm"
              variant="outline"
              className="border-[#2a2a2a] text-gray-300 hover:bg-[#2a2a2a] hover:text-white justify-start"
              onClick={() => playAnnouncement(ANNOUNCEMENT_TYPES.ROUND2, currentDancer.name)}
              disabled={generatingType === ANNOUNCEMENT_TYPES.ROUND2}
            >
              {generatingType === ANNOUNCEMENT_TYPES.ROUND2 ? (
                <Loader2 className="w-3 h-3 mr-2 animate-spin" />
              ) : (
                <Mic className="w-3 h-3 mr-2" />
              )}
              Round 2
            </Button>
            
            <Button
              size="sm"
              variant="outline"
              className="border-[#2a2a2a] text-gray-300 hover:bg-[#2a2a2a] hover:text-white justify-start"
              onClick={() => playAnnouncement(ANNOUNCEMENT_TYPES.OUTRO, currentDancer.name)}
              disabled={generatingType === ANNOUNCEMENT_TYPES.OUTRO}
            >
              {generatingType === ANNOUNCEMENT_TYPES.OUTRO ? (
                <Loader2 className="w-3 h-3 mr-2 animate-spin" />
              ) : (
                <Mic className="w-3 h-3 mr-2" />
              )}
              Outro
            </Button>
            
            {nextDancer && (
              <Button
                size="sm"
                variant="outline"
                className="border-[#2a2a2a] text-gray-300 hover:bg-[#2a2a2a] hover:text-white justify-start"
                onClick={() => playAnnouncement(ANNOUNCEMENT_TYPES.TRANSITION, currentDancer.name, nextDancer.name)}
                disabled={generatingType === ANNOUNCEMENT_TYPES.TRANSITION}
              >
                {generatingType === ANNOUNCEMENT_TYPES.TRANSITION ? (
                  <Loader2 className="w-3 h-3 mr-2 animate-spin" />
                ) : (
                  <Mic className="w-3 h-3 mr-2" />
                )}
                Transition
              </Button>
            )}
          </div>
        </div>
      )}

      {!currentDancer && (
        <div className="text-center py-4 text-gray-500 text-sm">
          <AlertCircle className="w-5 h-5 mx-auto mb-2 text-gray-600" />
          Start rotation to enable announcements
        </div>
      )}
    </div>
  );
});

AnnouncementSystem.displayName = 'AnnouncementSystem';

export default AnnouncementSystem;