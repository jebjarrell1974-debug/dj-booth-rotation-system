import React, { useRef, useEffect, useCallback, useState, forwardRef, useImperativeHandle } from 'react';

const MAX_SONG_DURATION = 180; // 3 minutes in seconds
const CROSSFADE_DURATION = 3; // seconds
const DUCK_VOLUME = 0.08;
const DUCK_TRANSITION = 0.5; // seconds

const AudioEngine = forwardRef(({ 
  onTrackEnd, 
  onTimeUpdate, 
  onTrackChange,
  musicFolder 
}, ref) => {
  const deckA = useRef(null);
  const deckB = useRef(null);
  const announcementAudio = useRef(null);
  const activeDeck = useRef('A');
  const masterVolume = useRef(0.8);
  const [isPlaying, setIsPlaying] = useState(false);
  const [currentTrack, setCurrentTrack] = useState(null);
  const [currentTime, setCurrentTime] = useState(0);
  const [duration, setDuration] = useState(0);
  const fadeAnimationRef = useRef(null);
  const isDucked = useRef(false);
  const lastTimeUpdateRef = useRef(0);

  useEffect(() => {
    // Initialize audio elements
    deckA.current = new Audio();
    deckB.current = new Audio();
    announcementAudio.current = new Audio();
    
    deckA.current.volume = masterVolume.current;
    deckB.current.volume = 0;
    
    return () => {
      deckA.current?.pause();
      deckB.current?.pause();
      announcementAudio.current?.pause();
      if (fadeAnimationRef.current) cancelAnimationFrame(fadeAnimationRef.current);
    };
  }, []);

  const getActiveDeck = () => activeDeck.current === 'A' ? deckA.current : deckB.current;
  const getInactiveDeck = () => activeDeck.current === 'A' ? deckB.current : deckA.current;

  const loadTrack = useCallback(async (fileHandle) => {
    if (!fileHandle) return null;
    
    const file = await fileHandle.getFile();
    const url = URL.createObjectURL(file);
    return { url, name: file.name, file };
  }, []);

  const playTrack = useCallback(async (fileHandle, crossfade = true) => {
    const trackData = await loadTrack(fileHandle);
    if (!trackData) return;

    // Clear any pending animations
    if (fadeAnimationRef.current) {
      cancelAnimationFrame(fadeAnimationRef.current);
      fadeAnimationRef.current = null;
    }

    const inactiveDeck = getInactiveDeck();
    const activeDeckEl = getActiveDeck();
    
    // Clean up old listeners from both decks
    inactiveDeck.onended = null;
    inactiveDeck.ontimeupdate = null;
    activeDeckEl.onended = null;
    activeDeckEl.ontimeupdate = null;
    
    // Reset inactive deck before loading new track
    inactiveDeck.currentTime = 0;
    inactiveDeck.src = '';
    inactiveDeck.src = trackData.url;
    await inactiveDeck.load();
    
    const effectiveDuration = Math.min(inactiveDeck.duration || MAX_SONG_DURATION, MAX_SONG_DURATION);
    setDuration(effectiveDuration);
    setCurrentTrack(trackData.name);
    setCurrentTime(0);
    lastTimeUpdateRef.current = 0;
    onTrackChange?.(trackData.name);
    
    if (crossfade && isPlaying) {
      // Crossfade between decks using RAF
      inactiveDeck.volume = 0;
      inactiveDeck.play();
      
      const targetVolume = isDucked.current ? DUCK_VOLUME : masterVolume.current;
      const startTime = performance.now();
      const fadeDuration = CROSSFADE_DURATION * 1000;
      
      const animateFade = (currentTime) => {
        const elapsed = currentTime - startTime;
        const progress = Math.min(elapsed / fadeDuration, 1);
        
        inactiveDeck.volume = progress * targetVolume;
        activeDeckEl.volume = (1 - progress) * targetVolume;
        
        if (progress < 1) {
          fadeAnimationRef.current = requestAnimationFrame(animateFade);
        } else {
          fadeAnimationRef.current = null;
          activeDeckEl.pause();
          activeDeckEl.src = '';
          activeDeck.current = activeDeck.current === 'A' ? 'B' : 'A';
        }
      };
      
      fadeAnimationRef.current = requestAnimationFrame(animateFade);
    } else {
      // Direct play (immediate switch)
      activeDeckEl.pause();
      activeDeckEl.src = '';
      inactiveDeck.volume = isDucked.current ? DUCK_VOLUME : masterVolume.current;
      inactiveDeck.currentTime = 0;
      inactiveDeck.play();
      activeDeck.current = activeDeck.current === 'A' ? 'B' : 'A';
    }
    
    setIsPlaying(true);
    
    // Set up time tracking with throttling (update every 1000ms to reduce re-renders)
    const deck = getActiveDeck();
    let trackEnded = false;
    
    const timeUpdateHandler = () => {
      const time = deck.currentTime;
      const now = performance.now();
      
      // Throttle updates to avoid excessive re-renders on Pi
      if (now - lastTimeUpdateRef.current > 1000) {
        lastTimeUpdateRef.current = now;
        setCurrentTime(time);
        onTimeUpdate?.(time, effectiveDuration);
      }
      
      if (time >= effectiveDuration && !trackEnded) {
        trackEnded = true;
        deck.pause();
        onTrackEnd?.();
      }
    };
    
    const endedHandler = () => {
      if (!trackEnded) {
        trackEnded = true;
        onTrackEnd?.();
      }
    };
    
    // Use on* properties instead of addEventListener for cleaner cleanup
    deck.ontimeupdate = timeUpdateHandler;
    deck.onended = endedHandler;
    
    return () => {
      deck.ontimeupdate = null;
      deck.onended = null;
    };
  }, [loadTrack, onTimeUpdate, onTrackEnd, onTrackChange]);

  const duck = useCallback(() => {
    isDucked.current = true;
    const deck = getActiveDeck();
    const startVolume = deck.volume;
    const startTime = performance.now();
    const duration = DUCK_TRANSITION * 1000;
    
    const animate = (currentTime) => {
      const elapsed = currentTime - startTime;
      const progress = Math.min(elapsed / duration, 1);
      deck.volume = startVolume - ((startVolume - DUCK_VOLUME) * progress);
      
      if (progress < 1) {
        requestAnimationFrame(animate);
      }
    };
    
    requestAnimationFrame(animate);
  }, []);

  const unduck = useCallback(() => {
    isDucked.current = false;
    const deck = getActiveDeck();
    const startVolume = deck.volume;
    const startTime = performance.now();
    const duration = DUCK_TRANSITION * 1000;
    
    const animate = (currentTime) => {
      const elapsed = currentTime - startTime;
      const progress = Math.min(elapsed / duration, 1);
      deck.volume = startVolume + ((masterVolume.current - startVolume) * progress);
      
      if (progress < 1) {
        requestAnimationFrame(animate);
      } else {
        deck.volume = masterVolume.current;
      }
    };
    
    requestAnimationFrame(animate);
  }, []);

  const playAnnouncement = useCallback(async (audioUrl) => {
    return new Promise(async (resolve) => {
      console.log('🔊 AudioEngine: Starting announcement playback');
      
      // Clean up any existing announcement
      if (announcementAudio.current) {
        announcementAudio.current.pause();
        announcementAudio.current.currentTime = 0;
      }
      
      duck();
      console.log('🔊 AudioEngine: Music ducked');
      
      let resolved = false;
      const cleanupAndResolve = () => {
        if (resolved) return;
        resolved = true;
        console.log('🔊 AudioEngine: Announcement ended, restoring music');
        unduck();
        resolve();
      };
      
      announcementAudio.current.src = audioUrl;
      announcementAudio.current.volume = 1.0;
      announcementAudio.current.loop = false;
      
      announcementAudio.current.onended = cleanupAndResolve;
      announcementAudio.current.onerror = (err) => {
        console.error('❌ Announcement error:', err);
        cleanupAndResolve();
      };
      
      try {
        await announcementAudio.current.play();
        console.log('🔊 AudioEngine: Announcement playing...');
      } catch (error) {
        console.error('❌ Failed to play announcement:', error);
        cleanupAndResolve();
      }
    });
  }, [duck, unduck]);

  const pause = useCallback(() => {
    getActiveDeck().pause();
    setIsPlaying(false);
  }, []);

  const resume = useCallback(() => {
    getActiveDeck().play();
    setIsPlaying(true);
  }, []);

  const setVolume = useCallback((vol) => {
    masterVolume.current = vol;
    if (!isDucked.current) {
      getActiveDeck().volume = vol;
    }
  }, []);

  const seek = useCallback((time) => {
    const deck = getActiveDeck();
    deck.currentTime = Math.min(time, MAX_SONG_DURATION);
  }, []);

  useImperativeHandle(ref, () => ({
    playTrack,
    pause,
    resume,
    duck,
    unduck,
    playAnnouncement,
    setVolume,
    seek,
    isPlaying,
    currentTrack,
    currentTime,
    duration
  }));

  return null; // This is a headless audio engine
});

AudioEngine.displayName = 'AudioEngine';

export default AudioEngine;