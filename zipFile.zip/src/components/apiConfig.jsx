
// DJ Booth API Configuration
// Set your API keys here once - they will be used throughout the app

export const API_CONFIG = {
  // Get your key from: https://platform.openai.com/api-keys
  openaiApiKey: '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',
  
  // Get your key from: https://elevenlabs.io/app/settings/api-keys
  elevenLabsApiKey: '6e6ca8d3c96256409bf197b076d0ede7fae7183d9bc02374d1e2be55fdd71342',
  
  // Optional: Get voice IDs from: https://elevenlabs.io/app/voice-library
  // Leave empty for default voice
  elevenLabsVoiceId: '8RV9Jl85RVagCJGw9qhY',
  
  // Enable/disable voiceover announcements
  announcementsEnabled: true
};
