import React, { useState, useEffect } from 'react';
import { base44 } from '@/api/base44Client';
import { useQuery } from '@tanstack/react-query';

export default function RotationDisplay() {
  const [stage, setStage] = useState(null);

  // Fetch the active stage
  const { data: stages = [] } = useQuery({
    queryKey: ['stages'],
    queryFn: () => base44.entities.Stage.list(),
    refetchInterval: 3000 // Poll every 3 seconds for updates (reduced Pi load)
  });

  const { data: dancers = [] } = useQuery({
    queryKey: ['dancers'],
    queryFn: () => base44.entities.Dancer.list()
  });

  useEffect(() => {
    const activeStage = stages.find(s => s.is_active);
    if (activeStage) {
      setStage(activeStage);
    }
  }, [stages]);

  if (!stage || !stage.rotation_order || stage.rotation_order.length === 0) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-purple-900 via-blue-900 to-purple-900 flex items-center justify-center">
        <div className="text-center">
          <h1 className="text-6xl font-bold text-white/90 mb-4">No Active Rotation</h1>
          <p className="text-2xl text-white/60">Waiting for DJ to start...</p>
        </div>
      </div>
    );
  }

  const currentIndex = stage.current_dancer_index || 0;
  const rotation = stage.rotation_order;
  
  const currentDancerId = rotation[currentIndex];
  const currentDancer = dancers.find(d => d.id === currentDancerId);
  
  // Get next dancers (up to 6)
  const nextDancers = [];
  for (let i = 1; i <= 6; i++) {
    const nextIndex = (currentIndex + i) % rotation.length;
    const nextDancerId = rotation[nextIndex];
    const dancer = dancers.find(d => d.id === nextDancerId);
    if (dancer) {
      nextDancers.push(dancer);
    }
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-purple-900 via-blue-900 to-purple-900 flex flex-col items-center justify-center p-12 overflow-hidden relative">

      {/* Content */}
      <div className="relative z-10 w-full max-w-4xl">
        {/* Currently On Stage */}
        <div className="text-center mb-16">
          <h2 className="text-4xl font-bold text-white/80 mb-6 tracking-wide uppercase">
            Currently On Stage
          </h2>
          {currentDancer ? (
            <div className="relative">
              <h1 className="text-8xl font-black text-white uppercase tracking-wider drop-shadow-2xl">
                {currentDancer.name}
              </h1>
              <div 
                className="absolute inset-0 blur-3xl opacity-50"
                style={{ 
                  background: `radial-gradient(circle, ${currentDancer.color || '#d4a574'} 0%, transparent 70%)` 
                }}
              />
            </div>
          ) : (
            <h1 className="text-8xl font-black text-white/40 uppercase">-</h1>
          )}
        </div>

        {/* Next On Stage */}
        <div className="text-center">
          <h2 className="text-4xl font-bold text-white/80 mb-8 tracking-wide uppercase">
            Next On Stage
          </h2>
          <div className="space-y-4 bg-black/20 backdrop-blur-md rounded-2xl p-8 border border-white/10">
            {nextDancers.map((dancer, idx) => (
              <div
                key={dancer.id}
                className="text-center py-4 border-b border-white/10 last:border-b-0 transition-all hover:bg-white/5"
              >
                <h3 className="text-4xl font-bold text-white uppercase tracking-wider">
                  {dancer.name}
                </h3>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
}