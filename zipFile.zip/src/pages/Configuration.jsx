import React, { useState, useEffect } from 'react';
import { base44 } from '@/api/base44Client';
import { useQuery } from '@tanstack/react-query';
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Switch } from "@/components/ui/switch";
import { Settings, Key, Mic, ArrowLeft, Download } from 'lucide-react';
import { Link } from 'react-router-dom';
import { createPageUrl } from '@/utils';
import { toast } from 'sonner';

export default function Configuration() {
  const [elevenLabsKey, setElevenLabsKey] = useState(() => 
    localStorage.getItem('elevenLabsApiKey') || ''
  );
  const [elevenLabsVoiceId, setElevenLabsVoiceId] = useState(() => 
    localStorage.getItem('elevenLabsVoiceId') || '21m00Tcm4TlvDq8ikWAM'
  );
  const [openaiKey, setOpenaiKey] = useState(() => 
    localStorage.getItem('openaiApiKey') || ''
  );
  const [announcementsEnabled, setAnnouncementsEnabled] = useState(() => {
    const stored = localStorage.getItem('announcementsEnabled');
    return stored === null ? true : stored === 'true';
  });
  const [saved, setSaved] = useState(false);
  const [isCaching, setIsCaching] = useState(false);

  // Fetch dancers and rotation
  const { data: dancers = [] } = useQuery({
    queryKey: ['dancers'],
    queryFn: () => base44.entities.Dancer.list()
  });

  const { data: stages = [] } = useQuery({
    queryKey: ['stages'],
    queryFn: () => base44.entities.Stage.list()
  });

  const activeStage = stages.find(s => s.is_active);
  const rotation = activeStage?.rotation_order || [];

  const saveSettings = () => {
    localStorage.setItem('elevenLabsApiKey', elevenLabsKey);
    localStorage.setItem('elevenLabsVoiceId', elevenLabsVoiceId);
    localStorage.setItem('openaiApiKey', openaiKey);
    localStorage.setItem('announcementsEnabled', announcementsEnabled.toString());
    setSaved(true);
    setTimeout(() => setSaved(false), 2000);
  };

  const handlePreCache = async () => {
    if (!elevenLabsKey) {
      toast.error('Please configure ElevenLabs API key first');
      return;
    }

    if (rotation.length === 0) {
      toast.error('No dancers in rotation to cache');
      return;
    }

    setIsCaching(true);
    toast.info('Pre-caching announcements...');

    try {
      const rotationDancers = rotation.map(id => dancers.find(d => d.id === id)).filter(Boolean);
      let cached = 0;
      let skipped = 0;

      for (let i = 0; i < rotationDancers.length; i++) {
        const dancer = rotationDancers[i];
        const nextDancer = rotationDancers[(i + 1) % rotationDancers.length];

        // Cache all announcement types
        const types = ['intro', 'round2', 'outro', 'transition'];
        
        for (const type of types) {
          const cacheKey = type === 'transition' 
            ? `${type}-${dancer.name}-${nextDancer.name}`
            : `${type}-${dancer.name}`;

          // Check if already cached
          const existing = await base44.entities.AnnouncementCache.filter({ cache_key: cacheKey });
          
          if (existing.length > 0) {
            skipped++;
            continue;
          }

          // Generate and cache
          const script = generateScript(type, dancer.name, type === 'transition' ? nextDancer.name : null);
          const audioUrl = await generateAudio(script);

          await base44.entities.AnnouncementCache.create({
            cache_key: cacheKey,
            audio_url: audioUrl,
            script: script,
            type: type
          });

          cached++;
        }
      }

      toast.success(`Pre-cached ${cached} announcements (${skipped} already cached)`);
    } catch (error) {
      console.error('Pre-cache error:', error);
      toast.error('Failed to pre-cache announcements');
    } finally {
      setIsCaching(false);
    }
  };

  const generateScript = (type, dancerName, nextDancerName) => {
    const scripts = {
      intro: `Welcome to the stage, ${dancerName}!`,
      round2: `${dancerName} for round two!`,
      outro: `Let's give it up for ${dancerName}!`,
      transition: `Thank you ${dancerName}! Next up, ${nextDancerName}!`
    };
    return scripts[type] || '';
  };

  const generateAudio = async (script) => {
    const response = await fetch('https://api.elevenlabs.io/v1/text-to-speech/' + elevenLabsVoiceId, {
      method: 'POST',
      headers: {
        'xi-api-key': elevenLabsKey,
        'Content-Type': 'application/json'
      },
      body: JSON.stringify({
        text: script,
        model_id: 'eleven_monolingual_v1',
        voice_settings: {
          stability: 0.5,
          similarity_boost: 0.75
        }
      })
    });

    if (!response.ok) throw new Error('Audio generation failed');

    const audioBlob = await response.blob();
    const file = new File([audioBlob], 'announcement.mp3', { type: 'audio/mpeg' });
    const { file_url } = await base44.integrations.Core.UploadFile({ file });
    return file_url;
  };

  return (
    <div className="min-h-screen bg-[#0a0a0a] text-white p-6">
      <div className="max-w-2xl mx-auto">
        {/* Header */}
        <div className="mb-8">
          <Link to={createPageUrl('DJBooth')}>
            <Button variant="ghost" className="mb-4 text-gray-400 hover:text-white">
              <ArrowLeft className="w-4 h-4 mr-2" />
              Back to DJ Booth
            </Button>
          </Link>
          <div className="flex items-center gap-3">
            <div className="w-12 h-12 rounded-lg bg-gradient-to-br from-[#d4a574] to-[#8b6914] flex items-center justify-center">
              <Settings className="w-6 h-6 text-black" />
            </div>
            <div>
              <h1 className="text-2xl font-bold">Configuration</h1>
              <p className="text-sm text-gray-500">System settings and API keys</p>
            </div>
          </div>
        </div>

        <div className="space-y-6">
          {/* Announcements Section */}
          <div className="bg-[#0f0f0f] rounded-xl border border-[#2a2a2a] p-6">
            <div className="flex items-center gap-3 mb-4">
              <Mic className="w-5 h-5 text-[#d4a574]" />
              <h2 className="text-lg font-semibold">Voice Announcements</h2>
            </div>
            
            <div className="flex items-center justify-between py-3">
              <div>
                <p className="text-sm font-medium text-white">Enable Automatic Announcements</p>
                <p className="text-xs text-gray-500 mt-1">
                  Play AI-generated voice announcements during dancer rotations
                </p>
              </div>
              <Switch
                checked={announcementsEnabled}
                onCheckedChange={setAnnouncementsEnabled}
              />
            </div>
          </div>

          {/* API Keys Section */}
          <div className="bg-[#0f0f0f] rounded-xl border border-[#2a2a2a] p-6">
            <div className="flex items-center gap-3 mb-4">
              <Key className="w-5 h-5 text-[#d4a574]" />
              <h2 className="text-lg font-semibold">API Configuration</h2>
            </div>
            
            <div className="space-y-4">
              <div className="space-y-2">
                <Label htmlFor="elevenlabs" className="text-gray-400">ElevenLabs API Key</Label>
                <Input
                  id="elevenlabs"
                  type="password"
                  value={elevenLabsKey}
                  onChange={(e) => setElevenLabsKey(e.target.value)}
                  placeholder="Enter your ElevenLabs API key"
                  className="bg-[#0a0a0a] border-[#2a2a2a]"
                />
                <p className="text-xs text-gray-500">Required for voice synthesis announcements</p>
              </div>

              <div className="space-y-2">
                <Label htmlFor="voiceid" className="text-gray-400">ElevenLabs Voice ID</Label>
                <Input
                  id="voiceid"
                  value={elevenLabsVoiceId}
                  onChange={(e) => setElevenLabsVoiceId(e.target.value)}
                  placeholder="21m00Tcm4TlvDq8ikWAM"
                  className="bg-[#0a0a0a] border-[#2a2a2a]"
                />
                <p className="text-xs text-gray-500">Find voice IDs in your ElevenLabs dashboard</p>
              </div>

              <div className="space-y-2">
                <Label htmlFor="openai" className="text-gray-400">OpenAI API Key (Optional)</Label>
                <Input
                  id="openai"
                  type="password"
                  value={openaiKey}
                  onChange={(e) => setOpenaiKey(e.target.value)}
                  placeholder="Enter your OpenAI API key"
                  className="bg-[#0a0a0a] border-[#2a2a2a]"
                />
                <p className="text-xs text-gray-500">Leave blank to use built-in AI for script generation</p>
              </div>
            </div>
          </div>

          {/* Save Button */}
          <Button 
            onClick={saveSettings}
            className="w-full bg-[#d4a574] hover:bg-[#c49464] text-black font-medium"
          >
            {saved ? 'Settings Saved!' : 'Save Settings'}
          </Button>

          {/* Pre-Cache Button */}
          <div className="bg-[#0f0f0f] rounded-xl border border-[#2a2a2a] p-6">
            <h3 className="text-sm font-semibold text-[#d4a574] uppercase tracking-wider mb-3">
              Pre-Cache Announcements
            </h3>
            <p className="text-sm text-gray-400 mb-4">
              Generate and cache all announcements for dancers in rotation. Already cached announcements will be skipped.
            </p>
            <Button 
              onClick={handlePreCache} 
              className="w-full bg-blue-600 hover:bg-blue-700 text-white"
              disabled={isCaching || !elevenLabsKey || rotation.length === 0}
            >
              <Download className="w-4 h-4 mr-2" />
              {isCaching ? 'Pre-caching...' : 'Pre-Cache Announcements'}
            </Button>
            {rotation.length > 0 && (
              <p className="text-xs text-gray-500 text-center mt-2">
                {rotation.length} dancers in rotation ready to cache
              </p>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}