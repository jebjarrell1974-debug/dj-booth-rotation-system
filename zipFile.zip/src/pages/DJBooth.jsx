import React, { useState, useRef, useCallback, useEffect } from 'react';
import { base44 } from '@/api/base44Client';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { Button } from "@/components/ui/button";
import { Tabs, TabsList, TabsTrigger, TabsContent } from "@/components/ui/tabs";
import { createPageUrl } from '@/utils';
import { API_CONFIG } from '@/components/apiConfig';
import { 
  Settings, 
  Music2, 
  Users, 
  Radio,
  Layers,
  Mic,
  AlertCircle,
  Key,
  Play,
  Pause,
  SkipForward,
  Volume2
} from 'lucide-react';
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";

import AudioEngine from '@/components/dj/AudioEngine';
import MusicLibrary from '@/components/dj/MusicLibrary';
import NowPlaying from '@/components/dj/NowPlaying';
import DancerRoster from '@/components/dj/DancerRoster';
import StageRotation from '@/components/dj/StageRotation';
import PlaylistEditor from '@/components/dj/PlaylistEditor';
import AnnouncementSystem from '@/components/dj/AnnouncementSystem';
import RotationPlaylistManager from '@/components/dj/RotationPlaylistManager';
import ManualAnnouncementPlayer from '@/components/dj/ManualAnnouncementPlayer';

const SONGS_PER_SET = 2;

export default function DJBooth() {
  const queryClient = useQueryClient();
  const audioEngineRef = useRef(null);
  
  // Music folder state
  const [musicFolder, setMusicFolder] = useState(null);
  const [tracks, setTracks] = useState([]);
  
  // Playback state
  const [isPlaying, setIsPlaying] = useState(false);
  const [currentTrack, setCurrentTrack] = useState(null);
  const [currentTime, setCurrentTime] = useState(0);
  const [duration, setDuration] = useState(0);
  const [volume, setVolume] = useState(0.8);
  const updateThrottleRef = useRef(0);
  
  // Rotation state
  const [rotation, setRotation] = useState([]);
  const [currentDancerIndex, setCurrentDancerIndex] = useState(0);
  const [currentSongNumber, setCurrentSongNumber] = useState(1);
  const [isRotationActive, setIsRotationActive] = useState(false);
  const [rotationSongs, setRotationSongs] = useState({}); // Store selected songs per dancer
  
  // UI state
  const [selectedDancer, setSelectedDancer] = useState(null);
  const [editingPlaylist, setEditingPlaylist] = useState(null);
  const [activeTab, setActiveTab] = useState('library');
  const [settingsOpen, setSettingsOpen] = useState(false);
  const [voiceId, setVoiceId] = useState(() => 
    localStorage.getItem('elevenLabsVoiceId') || ''
  );
  
  // Configuration (from config file)
  const [elevenLabsKey, setElevenLabsKey] = useState('');
  const [openaiKey, setOpenaiKey] = useState('');
  const [announcementsEnabled, setAnnouncementsEnabled] = useState(true);

  // Announcement reference
  const announcementRef = useRef(null);

  // Load API config on mount
  useEffect(() => {
    setElevenLabsKey(API_CONFIG.elevenLabsApiKey);
    setOpenaiKey(API_CONFIG.openaiApiKey);
    setAnnouncementsEnabled(API_CONFIG.announcementsEnabled);
    setVoiceId(API_CONFIG.elevenLabsVoiceId);
  }, []);

  // Fetch dancers
  const { data: dancers = [] } = useQuery({
    queryKey: ['dancers'],
    queryFn: () => base44.entities.Dancer.list(),
    staleTime: 60000, // 1 minute
    gcTime: 120000 // 2 minutes (formerly cacheTime)
  });

  // Fetch or create stage
  const { data: stages = [] } = useQuery({
    queryKey: ['stages'],
    queryFn: () => base44.entities.Stage.list(),
    staleTime: 30000, // 30 seconds
    gcTime: 60000 // 1 minute
  });

  const activeStage = stages.find(s => s.is_active);

  // Mutations
  const createDancerMutation = useMutation({
    mutationFn: async (data) => {
      const result = await base44.entities.Dancer.create(data);
      return result;
    },
    onSuccess: async () => {
      await queryClient.invalidateQueries({ queryKey: ['dancers'] });
      await queryClient.refetchQueries({ queryKey: ['dancers'] });
    }
  });

  const updateStageMutation = useMutation({
    mutationFn: ({ id, data }) => base44.entities.Stage.update(id, data),
    onSuccess: () => queryClient.invalidateQueries({ queryKey: ['stages'] })
  });

  const addDancer = async (data) => {
    const result = await createDancerMutation.mutateAsync(data);
    return result;
  };

  const updateDancerMutation = useMutation({
    mutationFn: ({ id, data }) => base44.entities.Dancer.update(id, data),
    onSuccess: () => queryClient.invalidateQueries({ queryKey: ['dancers'] })
  });

  const deleteDancerMutation = useMutation({
    mutationFn: (id) => base44.entities.Dancer.delete(id),
    onSuccess: () => queryClient.invalidateQueries({ queryKey: ['dancers'] })
  });

  // Get current dancer
  const currentDancer = rotation[currentDancerIndex] 
    ? dancers.find(d => d.id === rotation[currentDancerIndex])
    : null;

  // Get track handle by name
  const getTrackHandle = useCallback((trackName) => {
    console.log(`🔍 GetTrackHandle: Looking for "${trackName}"`);
    console.log(`📚 Available tracks:`, tracks.map(t => t.name).slice(0, 5));
    const handle = tracks.find(t => t.name === trackName)?.handle;
    if (!handle) {
      console.warn(`⚠️ GetTrackHandle: Track "${trackName}" not found in library of ${tracks.length} tracks`);
      // Try loose match
      const looseMatch = tracks.find(t => t.name.includes(trackName.split('.')[0]));
      if (looseMatch) {
        console.log(`✅ GetTrackHandle: Found loose match: "${looseMatch.name}"`);
        return looseMatch.handle;
      }
    } else {
      console.log(`✅ GetTrackHandle: Found "${trackName}"`);
    }
    return handle;
  }, [tracks]);

  // Play a specific track
  const playTrack = useCallback(async (trackHandle) => {
    if (!trackHandle) {
      console.error('❌ PlayTrack: No track handle provided');
      return;
    }
    if (!audioEngineRef.current) {
      console.error('❌ PlayTrack: Audio engine not initialized');
      return;
    }
    console.log('🎵 PlayTrack: Playing track with handle');
    await audioEngineRef.current.playTrack(trackHandle, isPlaying);
    setIsPlaying(true);
  }, [isPlaying]);

  // Handle folder connection
  const handleFolderConnected = useCallback(async (folder, files) => {
    setTracks(files);
    
    // Auto-start playing a random track as soon as library is connected
    if (files.length > 0 && !isPlaying) {
      const randomTrack = files[Math.floor(Math.random() * files.length)];
      await playTrack(randomTrack.handle);
    }
  }, [isPlaying, playTrack]);

  // Get random track handles from library
  const getRandomTracks = useCallback((count) => {
    const shuffled = [...tracks].sort(() => Math.random() - 0.5);
    const selected = shuffled.slice(0, count);
    console.log(`🎵 GetRandomTracks: Selected ${selected.length} tracks from ${tracks.length} available`);
    return selected; // Return track objects, not names
  }, [tracks]);

  // Get tracks for dancer's set - selects 2 songs from their playlist or random from library
  const getDancerTracks = useCallback((dancer) => {
    // If dancer has a playlist, match names to track handles
    if (dancer?.playlist?.length > 0) {
      const selected = [];
      for (const playlistName of dancer.playlist) {
        const track = tracks.find(t => t.name === playlistName);
        if (track) {
          selected.push(track);
        }
      }
      if (selected.length > 0) {
        const shuffled = selected.sort(() => Math.random() - 0.5);
        return shuffled.slice(0, SONGS_PER_SET);
      }
    }
    // Otherwise, select 2 random songs from library
    return getRandomTracks(SONGS_PER_SET);
  }, [getRandomTracks, tracks]);

  // Play announcement helper
  const playAnnouncement = useCallback(async (type, currentDancerName, nextDancerName = null) => {
    if (!announcementsEnabled) {
      console.log('Announcements disabled, skipping');
      return;
    }
    if (!announcementRef.current) {
      console.log('Announcement ref not ready, skipping');
      return;
    }
    console.log(`🎤 Playing ${type} announcement for ${currentDancerName}`);
    try {
      await announcementRef.current.playAutoAnnouncement(type, currentDancerName, nextDancerName);
      console.log(`✅ ${type} announcement completed`);
    } catch (error) {
      console.error('❌ Announcement failed:', error);
    }
  }, [announcementsEnabled]);

  // Update stage in database
  const updateStageState = useCallback(async (index) => {
    if (activeStage) {
      await updateStageMutation.mutateAsync({
        id: activeStage.id,
        data: {
          rotation_order: rotation,
          current_dancer_index: index,
          is_active: true
        }
      });
    } else if (rotation.length > 0) {
      // Create stage if it doesn't exist
      await base44.entities.Stage.create({
        name: 'Main Stage',
        rotation_order: rotation,
        current_dancer_index: index,
        is_active: true
      });
      queryClient.invalidateQueries({ queryKey: ['stages'] });
    }
  }, [activeStage, rotation, updateStageMutation, queryClient]);

  // Start rotation
  const startRotation = useCallback(async () => {
    if (rotation.length === 0 || !tracks.length) {
      console.error('❌ StartRotation: rotation.length=' + rotation.length + ', tracks.length=' + tracks.length);
      return;
    }
    
    // Pre-select songs for all dancers in rotation (now storing track objects)
    const selectedSongs = {};
    rotation.forEach(dancerId => {
      const dancer = dancers.find(d => d.id === dancerId);
      if (dancer) {
        selectedSongs[dancerId] = getDancerTracks(dancer);
      }
    });
    setRotationSongs(selectedSongs);
    
    setIsRotationActive(true);
    setCurrentDancerIndex(0);
    setCurrentSongNumber(1);
    
    // Update stage state
    await updateStageState(0);
    
    const dancer = dancers.find(d => d.id === rotation[0]);
    console.log('🎤 StartRotation: First dancer:', dancer?.name);
    if (dancer) {
      const dancerTracks = selectedSongs[rotation[0]];
      console.log('🎵 StartRotation: Selected tracks for', dancer.name, ':', dancerTracks.map(t => t.name));
      const firstTrack = dancerTracks[0];
      if (firstTrack && firstTrack.handle) {
        // Small delay to ensure refs are ready
        setTimeout(async () => {
          console.log('🎤 StartRotation: Playing intro announcement');
          await playAnnouncement('intro', dancer.name);
        }, 100);
        console.log('🎵 StartRotation: Playing first track:', firstTrack.name);
        await playTrack(firstTrack.handle);
      } else {
        console.error('❌ StartRotation: No valid track object for', firstTrack);
      }
    }
  }, [rotation, dancers, getDancerTracks, playTrack, tracks, playAnnouncement, updateStageState]);

  // Handle skip - manual skip with announcements
  const handleSkip = useCallback(async () => {
    if (!isRotationActive) {
      if (tracks.length > 0) {
        const randomTrack = tracks[Math.floor(Math.random() * tracks.length)];
        await playTrack(randomTrack.handle);
      }
      return;
    }
    
    const dancer = dancers.find(d => d.id === rotation[currentDancerIndex]);
    if (!dancer) return;
    
    const dancerTracks = rotationSongs[rotation[currentDancerIndex]];
    if (!dancerTracks || dancerTracks.length === 0) return;
    
    if (currentSongNumber < SONGS_PER_SET) {
      // Skip to second song
      const nextTrack = dancerTracks[currentSongNumber];
      setCurrentSongNumber(prev => prev + 1);
      
      if (nextTrack && nextTrack.handle) {
        console.log('🎵 HandleSkip: Playing next track:', nextTrack.name);
        await playTrack(nextTrack.handle, false); // Direct switch, no crossfade
      }
      // Play round 2 announcement while music is playing
      playAnnouncement('round2', dancer.name).catch(err => console.error('Round 2 announcement failed:', err));
    } else {
      // Skip to next dancer
      const nextIndex = (currentDancerIndex + 1) % rotation.length;
      const nextDancer = dancers.find(d => d.id === rotation[nextIndex]);
      
      if (nextDancer) {
        const nextDancerTracks = rotationSongs[rotation[nextIndex]];
        const nextTrack = nextDancerTracks?.[0];
        if (nextTrack && nextTrack.handle) {
          console.log('🎵 HandleSkip: Playing next dancer:', nextDancer.name, 'track:', nextTrack.name);
          await playTrack(nextTrack.handle, false); // Direct switch, no crossfade
        }
        
        setCurrentDancerIndex(nextIndex);
        setCurrentSongNumber(1);
        await updateStageState(nextIndex);
        
        // Play transition announcement while music is playing
        playAnnouncement('transition', dancer.name, nextDancer.name).catch(err => console.error('Transition announcement failed:', err));
      }
    }
  }, [isRotationActive, dancers, rotation, currentDancerIndex, currentSongNumber, rotationSongs, playTrack, playAnnouncement, updateStageState]);

  // Handle track end - advance to next song or dancer
  const handleTrackEnd = useCallback(async () => {
    // If no rotation active, play random track to keep music going
    if (!isRotationActive) {
      if (tracks.length > 0) {
        const randomTrack = tracks[Math.floor(Math.random() * tracks.length)];
        await playTrack(randomTrack.handle);
      }
      return;
    }
    
    const dancer = dancers.find(d => d.id === rotation[currentDancerIndex]);
    if (!dancer) return;
    
    const dancerTracks = rotationSongs[rotation[currentDancerIndex]];
    if (!dancerTracks || dancerTracks.length === 0) return;
    
    if (currentSongNumber < SONGS_PER_SET) {
      // End of first song - play round 2 announcement
      const nextTrack = dancerTracks[currentSongNumber];
      setCurrentSongNumber(prev => prev + 1);
      
      // Start next track immediately, then play announcement
      if (nextTrack && nextTrack.handle) {
        console.log('🎵 HandleTrackEnd: Playing round 2 track:', nextTrack.name);
        await playTrack(nextTrack.handle);
      }
      // Play announcement while music is playing
      playAnnouncement('round2', dancer.name).catch(err => console.error('Round 2 announcement failed:', err));
    } else {
      // End of second song - play outro/transition to next dancer
      const nextIndex = (currentDancerIndex + 1) % rotation.length;
      const nextDancer = dancers.find(d => d.id === rotation[nextIndex]);
      
      if (nextDancer) {
        // Start next track immediately
        const nextDancerTracks = rotationSongs[rotation[nextIndex]];
        const nextTrack = nextDancerTracks?.[0];
        if (nextTrack && nextTrack.handle) {
          console.log('🎵 HandleTrackEnd: Playing next dancer:', nextDancer.name, 'track:', nextTrack.name);
          await playTrack(nextTrack.handle);
        }
        
        // Move to next dancer
        setCurrentDancerIndex(nextIndex);
        setCurrentSongNumber(1);
        
        // Update stage state
        await updateStageState(nextIndex);
        
        // Play transition announcement while music is playing
        playAnnouncement('transition', dancer.name, nextDancer.name).catch(err => console.error('Transition announcement failed:', err));
      }
    }
  }, [isRotationActive, dancers, rotation, currentDancerIndex, currentSongNumber, rotationSongs, playTrack, playAnnouncement, updateStageState]);

  // Handle announcement playback
  const handleAnnouncementPlay = useCallback(async (audioUrl) => {
    if (audioEngineRef.current) {
      await audioEngineRef.current.playAnnouncement(audioUrl);
    }
  }, []);

  // Rotation management
  const addToRotation = async (dancerId) => {
    if (!rotation.includes(dancerId)) {
      const newRotation = [...rotation, dancerId];
      setRotation(newRotation);
    }
  };

  const stopRotation = useCallback(() => {
    setIsRotationActive(false);
    // Music keeps playing, just stop the rotation
  }, []);

  const removeFromRotation = (dancerId) => {
    setRotation(rotation.filter(id => id !== dancerId));
  };

  const moveUp = (index) => {
    if (index > 0) {
      const newRotation = [...rotation];
      [newRotation[index], newRotation[index - 1]] = [newRotation[index - 1], newRotation[index]];
      setRotation(newRotation);
    }
  };

  const moveDown = (index) => {
    if (index < rotation.length - 1) {
      const newRotation = [...rotation];
      [newRotation[index], newRotation[index + 1]] = [newRotation[index + 1], newRotation[index]];
      setRotation(newRotation);
    }
  };



  return (
    <div className="min-h-screen bg-[#0a0a0a] text-white">
      {/* Audio Engine (headless) */}
      <AudioEngine
        ref={audioEngineRef}
        musicFolder={musicFolder}
        onTrackEnd={handleTrackEnd}
        onTimeUpdate={(time, dur) => {
          setCurrentTime(time);
          setDuration(dur);
        }}
        onTrackChange={setCurrentTrack}
      />

      {/* Announcement System (ref only, UI is in announcements tab) */}
      <AnnouncementSystem
        ref={announcementRef}
        dancers={dancers}
        rotation={rotation}
        currentDancerIndex={currentDancerIndex}
        onPlay={handleAnnouncementPlay}
        elevenLabsApiKey={elevenLabsKey}
        openaiApiKey={openaiKey}
        hideUI={true}
      />

      {/* Header */}
      <header className="border-b border-[#1a1a1a] px-6 py-4">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-6">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 rounded-lg bg-gradient-to-br from-[#d4a574] to-[#8b6914] flex items-center justify-center">
                <Radio className="w-5 h-5 text-black" />
              </div>
              <div>
                <h1 className="text-xl font-bold tracking-tight">DJ Booth</h1>
                <p className="text-xs text-gray-500">Automated Rotation System</p>
              </div>
            </div>

            {/* Now Playing - Compact */}
            <div className="bg-[#0f0f0f] rounded-lg border border-[#2a2a2a] p-3 min-w-[320px]">
              <div className="flex items-center gap-3 mb-2">
                {currentDancer && (
                  <div 
                    className="w-6 h-6 rounded-full flex items-center justify-center text-black font-bold text-xs flex-shrink-0"
                    style={{ backgroundColor: currentDancer.color || '#d4a574' }}
                  >
                    {currentDancer.name.charAt(0).toUpperCase()}
                  </div>
                )}
                <div className="flex-1 min-w-0">
                  <p className="text-xs text-gray-500">
                    {currentDancer ? `${currentDancer.name}${isRotationActive ? ` - Song ${currentSongNumber}/2` : ''}` : 'No track loaded'}
                  </p>
                  <p className="text-sm text-white truncate">{currentTrack || 'Select a track'}</p>
                </div>
              </div>
              
              <div className="flex items-center gap-2">
                <Button
                  size="icon"
                  variant="ghost"
                  className="w-7 h-7 text-white hover:bg-[#2a2a2a]"
                  onClick={() => {
                    if (isPlaying) {
                      audioEngineRef.current?.pause();
                      setIsPlaying(false);
                    } else {
                      audioEngineRef.current?.resume();
                      setIsPlaying(true);
                    }
                  }}
                >
                  {isPlaying ? <Pause className="w-4 h-4" /> : <Play className="w-4 h-4" />}
                </Button>
                
                <Button
                  size="icon"
                  variant="ghost"
                  className="w-7 h-7 text-white hover:bg-[#2a2a2a]"
                  onClick={handleSkip}
                >
                  <SkipForward className="w-4 h-4" />
                </Button>
                
                <div className="flex-1 flex items-center gap-2">
                  <Volume2 className="w-4 h-4 text-gray-500" />
                  <input
                    type="range"
                    min="0"
                    max="100"
                    value={volume * 100}
                    onChange={(e) => {
                      const vol = parseFloat(e.target.value) / 100;
                      setVolume(vol);
                      audioEngineRef.current?.setVolume(vol);
                    }}
                    className="flex-1 h-1"
                  />
                </div>
              </div>
              
              {duration > 0 && (
                <div className="mt-2 text-xs text-gray-500 text-center">
                  {Math.floor(currentTime / 60)}:{String(Math.floor(currentTime % 60)).padStart(2, '0')} / {Math.floor(duration / 60)}:{String(Math.floor(duration % 60)).padStart(2, '0')}
                </div>
              )}
            </div>
          </div>
          
          <div className="flex items-center gap-3">
            {/* Tab Navigation */}
            <div className="flex items-center gap-1 bg-[#0f0f0f] rounded-lg p-1 border border-[#1a1a1a]">
              <Button
                variant="ghost"
                size="sm"
                onClick={() => setActiveTab('rotation')}
                className={`${activeTab === 'rotation' ? 'bg-[#d4a574] text-black' : 'text-gray-400 hover:text-white'}`}
              >
                <Layers className="w-4 h-4 mr-1" />
                Rotation
              </Button>
              <Button
                variant="ghost"
                size="sm"
                onClick={() => setActiveTab('dancers')}
                className={`${activeTab === 'dancers' ? 'bg-[#d4a574] text-black' : 'text-gray-400 hover:text-white'}`}
              >
                <Users className="w-4 h-4 mr-1" />
                Dancers
              </Button>
              <Button
                variant="ghost"
                size="sm"
                onClick={() => setActiveTab('library')}
                className={`${activeTab === 'library' ? 'bg-[#d4a574] text-black' : 'text-gray-400 hover:text-white'}`}
              >
                <Music2 className="w-4 h-4 mr-1" />
                Library
              </Button>
              <Button
                variant="ghost"
                size="sm"
                onClick={() => setActiveTab('announcements')}
                className={`${activeTab === 'announcements' ? 'bg-[#d4a574] text-black' : 'text-gray-400 hover:text-white'}`}
              >
                <Mic className="w-4 h-4 mr-1" />
                Announcements
              </Button>
            </div>
            
            {(!elevenLabsKey || !openaiKey) && (
              <div className="flex items-center gap-2 px-3 py-1.5 bg-amber-500/10 border border-amber-500/30 rounded-lg">
                <AlertCircle className="w-4 h-4 text-amber-500" />
                <span className="text-xs text-amber-400">API keys not configured</span>
              </div>
            )}
            {rotation.length > 0 && (
              <Button
                onClick={isRotationActive ? stopRotation : startRotation}
                className={isRotationActive 
                  ? "bg-red-600 hover:bg-red-700 text-white" 
                  : "bg-green-600 hover:bg-green-700 text-white"
                }
              >
                {isRotationActive ? 'Stop Rotation' : 'Start Rotation'}
              </Button>
            )}
            <a href={createPageUrl('RotationDisplay')} target="_blank" rel="noopener noreferrer">
              <Button
                variant="outline"
                size="sm"
                className="border-[#2a2a2a] text-gray-300 hover:bg-[#2a2a2a] hover:text-white"
              >
                <Radio className="w-4 h-4 mr-2" />
                Open Display
              </Button>
            </a>
            <Button
              variant="ghost"
              size="icon"
              className="text-gray-400 hover:text-white hover:bg-[#1a1a1a]"
              onClick={() => setSettingsOpen(true)}
            >
              <Settings className="w-5 h-5" />
            </Button>
          </div>
        </div>
      </header>

      {/* Main Content */}
      <div className="flex h-[calc(100vh-73px)]">
        {/* Main Area - Full Screen */}
        <div className="flex-1 relative">
          {/* Content Area */}
          <div className="h-full p-6">
            {activeTab === 'rotation' && (
              <RotationPlaylistManager
                dancers={dancers}
                rotation={rotation}
                tracks={tracks}
                onSavePlaylists={(playlists) => {
                  Object.entries(playlists).forEach(([dancerId, playlist]) => {
                    updateDancerMutation.mutate({ 
                      id: dancerId, 
                      data: { playlist } 
                    });
                  });
                }}
                onAddToRotation={addToRotation}
                onRemoveFromRotation={removeFromRotation}
                onStartRotation={startRotation}
                isRotationActive={isRotationActive}
                onMoveUp={moveUp}
                onMoveDown={moveDown}
              />
            )}
            
            {activeTab === 'dancers' && (
              <div className="h-full bg-[#0f0f0f] rounded-xl border border-[#2a2a2a] p-6">
                <DancerRoster
                  dancers={dancers}
                  onAddDancer={addDancer}
                  onEditDancer={(id, data) => updateDancerMutation.mutate({ id, data })}
                  onDeleteDancer={(id) => deleteDancerMutation.mutate(id)}
                  onSelectDancer={(dancer) => {
                    setSelectedDancer(dancer);
                    setEditingPlaylist(dancer);
                  }}
                  selectedDancerId={selectedDancer?.id}
                />
              </div>
            )}
            
            {activeTab === 'library' && (
              <div className="h-full bg-[#0f0f0f] rounded-xl border border-[#2a2a2a] p-6">
                <MusicLibrary
                  musicFolder={musicFolder}
                  setMusicFolder={setMusicFolder}
                  onFolderConnected={handleFolderConnected}
                  onTrackSelect={(track) => {
                    if (editingPlaylist) return;
                    playTrack(track.handle);
                  }}
                />
              </div>
            )}
            
            {activeTab === 'announcements' && (
              <div className="h-full flex flex-col gap-6">
                <AnnouncementSystem
                  ref={announcementRef}
                  dancers={dancers}
                  rotation={rotation}
                  currentDancerIndex={currentDancerIndex}
                  onPlay={handleAnnouncementPlay}
                  elevenLabsApiKey={elevenLabsKey}
                  openaiApiKey={openaiKey}
                  hideUI={false}
                />
                <div className="bg-[#0f0f0f] rounded-xl border border-[#2a2a2a] p-6 flex-1">
                  <ManualAnnouncementPlayer onPlay={handleAnnouncementPlay} />
                </div>
              </div>
            )}
          </div>
        </div>
      </div>

      {/* Playlist Editor Modal */}
      {editingPlaylist && (
        <PlaylistEditor
          dancer={editingPlaylist}
          tracks={tracks}
          onSave={(playlist) => {
            updateDancerMutation.mutate({ 
              id: editingPlaylist.id, 
              data: { playlist } 
            });
          }}
          onClose={() => {
            setEditingPlaylist(null);
            setSelectedDancer(null);
          }}
        />
      )}

      {/* Settings Modal */}
      <Dialog open={settingsOpen} onOpenChange={setSettingsOpen}>
        <DialogContent className="bg-[#0f0f0f] border-[#2a2a2a] text-white max-w-2xl">
          <DialogHeader>
            <DialogTitle>Settings</DialogTitle>
          </DialogHeader>
          
          <div className="space-y-6 py-4">
            {/* API Keys Section */}
            <div className="space-y-4">
              <h3 className="text-sm font-semibold text-[#d4a574] uppercase tracking-wider">API Keys</h3>
              
              <div className="space-y-2">
                <Label htmlFor="openai-key">OpenAI API Key</Label>
                <Input
                  id="openai-key"
                  type="password"
                  value={openaiKey}
                  onChange={(e) => setOpenaiKey(e.target.value)}
                  placeholder="sk-..."
                  className="bg-[#1a1a1a] border-[#2a2a2a]"
                />
                <p className="text-xs text-gray-500">Used for generating announcement scripts</p>
              </div>

              <div className="space-y-2">
                <Label htmlFor="elevenlabs-key">ElevenLabs API Key</Label>
                <Input
                  id="elevenlabs-key"
                  type="password"
                  value={elevenLabsKey}
                  onChange={(e) => setElevenLabsKey(e.target.value)}
                  placeholder="sk_..."
                  className="bg-[#1a1a1a] border-[#2a2a2a]"
                />
                <p className="text-xs text-gray-500">Used for text-to-speech announcements</p>
              </div>

              <div className="space-y-2">
                <Label htmlFor="voice-id">ElevenLabs Voice ID (optional)</Label>
                <Input
                  id="voice-id"
                  value={voiceId}
                  onChange={(e) => setVoiceId(e.target.value)}
                  placeholder="21m00Tcm4TlvDq8ikWAM"
                  className="bg-[#1a1a1a] border-[#2a2a2a]"
                />
                <p className="text-xs text-gray-500">Leave empty for default voice</p>
              </div>
            </div>

            {/* Announcement Settings */}
            <div className="space-y-4">
              <h3 className="text-sm font-semibold text-[#d4a574] uppercase tracking-wider">Announcements</h3>
              
              <div className="flex items-center justify-between">
                <div>
                  <Label>Enable Voiceover Announcements</Label>
                  <p className="text-xs text-gray-500 mt-1">
                    Automatically announce dancers during rotation
                  </p>
                </div>
                <input
                  type="checkbox"
                  checked={announcementsEnabled}
                  onChange={(e) => setAnnouncementsEnabled(e.target.checked)}
                  className="w-10 h-6"
                />
              </div>
            </div>

            {/* Save Button */}
            <div className="flex justify-end gap-3 pt-4 border-t border-[#2a2a2a]">
              <Button
                variant="outline"
                onClick={() => setSettingsOpen(false)}
                className="border-[#2a2a2a]"
              >
                Cancel
              </Button>
              <Button
                onClick={() => {
                  setSettingsOpen(false);
                  alert('Settings updated for this session.\n\nTo make them permanent, edit:\ncomponents/apiConfig.js');
                }}
                className="bg-[#d4a574] hover:bg-[#c4956a] text-black"
              >
                OK
              </Button>
            </div>
          </div>
        </DialogContent>
      </Dialog>

    </div>
  );
}