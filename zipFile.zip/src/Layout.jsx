import React from 'react';

export default function Layout({ children, currentPageName }) {
  return (
    <div className="min-h-screen bg-[#0a0a0a]">
      <style>{`
        :root {
          --background: 0 0% 4%;
          --foreground: 0 0% 100%;
          --card: 0 0% 6%;
          --card-foreground: 0 0% 100%;
          --popover: 0 0% 6%;
          --popover-foreground: 0 0% 100%;
          --primary: 30 45% 64%;
          --primary-foreground: 0 0% 0%;
          --secondary: 0 0% 10%;
          --secondary-foreground: 0 0% 100%;
          --muted: 0 0% 15%;
          --muted-foreground: 0 0% 60%;
          --accent: 30 45% 64%;
          --accent-foreground: 0 0% 0%;
          --destructive: 0 62% 50%;
          --destructive-foreground: 0 0% 100%;
          --border: 0 0% 15%;
          --input: 0 0% 15%;
          --ring: 30 45% 64%;
          --radius: 0.5rem;
        }
        
        body {
          background-color: #0a0a0a;
          color: white;
        }
        
        /* Custom scrollbar for dark theme */
        ::-webkit-scrollbar {
          width: 8px;
          height: 8px;
        }
        ::-webkit-scrollbar-track {
          background: #0f0f0f;
        }
        ::-webkit-scrollbar-thumb {
          background: #2a2a2a;
          border-radius: 4px;
        }
        ::-webkit-scrollbar-thumb:hover {
          background: #3a3a3a;
        }
        
        /* Slider styling */
        [data-orientation="horizontal"] [data-radix-slider-track] {
          background: #2a2a2a;
        }
        [data-orientation="horizontal"] [data-radix-slider-range] {
          background: #d4a574;
        }
        [data-radix-slider-thumb] {
          background: #d4a574;
          border: none;
        }
      `}</style>
      {children}
    </div>
  );
}